# Historial de versiones

## 0.77.0 · en curso (P10-B, C y D)

- P10-B · Último Máximo Glacial y refugios (28/11/2026): 5 páginas (≈ 25.000 palabras) en «Prehistoria reciente › Último Máximo Glacial»: el UMG, los refugios glaciares, Beringia, la recolonización tardiglaciar y el Dryas Reciente, con unos 40 enlaces ⌖ a yacimientos y culturas del mapa.

## 0.76.0 · 28 de noviembre de 2026

- Enciclopedia P10-0 · Desplegable «Prehistoria reciente» en el índice, con portada (`prehistoria`) que se abre al desplegarlo y subdesplegables por subcarpeta de `enciclopedia/prehistoria/` (Paleolítico superior, Último Máximo Glacial, poblamiento, Epipaleolítico y Mesolítico, Neolítico, megalitismo, primeros metales y culturas del mapa). El tema heredado «Del poblamiento a las primeras sociedades productoras» pasa del desplegable de Evolución humana al de Neolítico hasta que se reescriba en P10-E.
- Enlaces `[[@CLAVE año|texto]]` a culturas y regiones culturales del mapa (`ownerKey` de `public/data/cultural-index.json`): el mapa viaja al año, se centra en el foco de la región y abre su ficha. El compilador valida las ventanas. También se admiten ya todos los puntos de evidencia con clave y ventana, no solo los de taxón.
- Enciclopedia P10-A · 11 páginas del Paleolítico superior (≈ 54.000 palabras, con la portada): arte rupestre, Chauvet, Lascaux, Altamira, arte al aire libre, arte paleolítico ibérico, arte mueble, música y ornamentos, enterramientos, economía y caza, sociedad y redes; y la portada con cronología comparada por continentes.
- Prueba de navegador nueva: la portada de la Prehistoria se abre desde su desplegable y un enlace de cultura (cerámica cardial, −4900) centra su región en el mapa.

## 0.75.0 · 23 de noviembre de 2026

- Enciclopedia P09-D · 10 páginas de tecnologías de la piedra (≈ 50.000 palabras de cuerpo) en «Evolución humana › Tecnologías de la piedra»: Lomekwiense, Olduvayense, Achelense, Asia oriental y la línea de Movius, Levallois y Musteriense, Edad de Piedra Media africana, industrias de transición, Auriñaciense, Gravetiense, y Solutrense y Magdaleniense, con enlaces a los puntos del mapa de sus yacimientos.
- Cierre de la fase P09 · Evolución humana: 81 páginas (≈ 403.000 palabras).
- Nuevo `PLAN.md` en la raíz: plan maestro con el estado de todas las fases y subfases (terminadas con casilla marcada) y el plan detallado de todo lo que queda (P10–P24, PX1, PX2 y deuda anotada).

## 0.74.0 · 23 de noviembre de 2026

- Enciclopedia P09-C · 16 monografías de yacimientos (≈ 85.000 palabras) en «Evolución humana › Yacimientos»: Atapuerca, Orce y Venta Micena, Olduvai, cuenca del Turkana, Afar (Hadar y Awash Medio), Laetoli, Cuna de la Humanidad, Dmanisi, Zhoukoudian, Sangiran y Trinil, Liang Bua, Denisova, Jebel Irhoud, Omo Kibish, Levante (Skhul, Qafzeh, Misliya, Tabun) y Gibraltar con El Sidrón.
- Enlaces de la enciclopedia al mapa: la sintaxis `[[@CLAVE año|texto]]` enlaza un yacimiento con su punto de evidencia del mapa (marcado con ⌖). Al pulsarlo se cierra la enciclopedia, el mapa viaja a ese año, centra el punto y abre su ficha. El compilador comprueba que la clave exista y que el punto se muestre ese año. Hay unos 370 enlaces a 92 puntos distintos en las páginas de yacimientos, procesos, especies y la portada.
- Los enlaces internos sin texto propio muestran en cursiva los nombres científicos del título de destino, sin asteriscos.

## 0.73.0 · 22 de noviembre de 2026

- Enciclopedia P09-B · 15 páginas de procesos de la evolución humana (≈ 90.000 palabras) en `enciclopedia/humanidad/procesos/`, dentro del desplegable «Evolución humana › Procesos»:
  - Sustituyen a los temas heredados con su mismo id (conservan al final sus esquemas, laboratorios y el comparador): orígenes de los homininos, australopitecos, *Homo* temprano y primeras dispersiones, diversidad del Pleistoceno, expansión de *Homo sapiens*, contacto y mezcla genética, especies y nombres, glaciaciones y ambientes humanos, y tecnología de la piedra.
  - Nuevas: bipedismo, cerebro y desarrollo, dieta y caza, lenguaje y cognición, fuego y cocina, y paleogenómica y ADN antiguo.
- Imágenes libres nuevas, entre ellas el hioides de Kebara, los huesos de rinoceronte despiezados de Kalinga, el uso de piedras por capuchinos, el esqueleto de Lucy y el quagga del primer ADN antiguo.

## 0.72.0 · 22 de noviembre de 2026

- Enciclopedia P09-A4 y A5 · las 15 fichas de linaje restantes (≈ 58.000 palabras); las 39 especies humanas del atlas tienen ya monografía propia:
  - A4 · Pleistoceno medio: *Homo antecessor*, *cepranensis*, *heidelbergensis*, *rhodesiensis*, *bodoensis*, *helmei*, *naledi*, población de Nesher Ramla, *longi* y *juluensis*.
  - A5 · Linajes tardíos: neandertales (la monografía más extensa, ≈ 10.000 palabras, con El Sidrón, Valdegoba, Zafarraya y Gibraltar), denisovanos, *Homo floresiensis*, *Homo luzonensis* y *Homo sapiens*.
- Imágenes libres nuevas (15), entre ellas el cráneo de La Chapelle-aux-Saints, la mandíbula de Xiahe, Jebel Irhoud, Florisbad, Bodo, Ceprano y Nesher Ramla. Commons limita las peticiones desde el entorno de trabajo en la nube; parte de las descargas se hicieron con el script de la enciclopedia desde el equipo local.

## 0.71.2 · 22 de noviembre de 2026

- Navegación: cada artículo abierto en la enciclopedia es una entrada del historial del navegador; los botones atrás/adelante del navegador o del ratón recorren los artículos, reabren la enciclopedia si se cerró y la cierran al salir de su primera página. Los botones ← → de la cabecera usan el mismo historial.
- Índice lateral: los desplegables pueden tener artículo de portada, que se abre al desplegarlos. «Escala temporal geológica» abre su artículo `escala-temporal` (que deja de aparecer suelto y pasa a ser la primera entrada del desplegable); «Evolución humana» abre la nueva portada `humanidad-evolucion-humana`.
- Evolución humana unificada: desaparece la rama duplicada «Humanidad»; el desplegable «Evolución humana» reúne la portada, el subdesplegable «Especies humanas» (los 39 linajes de más antiguo a más reciente, con la monografía nueva donde existe y la ficha heredada donde aún no), «Procesos», «Yacimientos» y «Tecnologías de la piedra». Los títulos con cursivas Markdown (*Homo erectus*) se muestran en cursiva en el índice y en el encabezado, sin asteriscos.
- Portada nueva «Evolución humana»: árbol evolutivo completo, cómo leerlo, grandes etapas, hitos y organización del apartado. El árbol deja de repetirse en cada ficha de especie, que muestra en su lugar una franja compacta con su posición en el tiempo frente a los demás linajes, un botón al árbol completo y el comparador. Los temas generales (orígenes, australopitecos, Homo temprano, diversidad, taxonomía) conservan el árbol completo.
- Denisovanos: la imagen de portada pasa a ser el molar original Denisova 4 (Thilo Parg, CC BY-SA 4.0); la foto de la entrada de la cueva queda para el tema de contacto y mezcla genética. Regenerados public/data/human-knowledge.json y el inventario Tierra/Investigacion/parte-6/integracion.json.

## 0.71.1 · 22 de noviembre de 2026

- Corregido el fallo del despliegue en «encyclopedia retains applicable dates…» (earth-integration): en las páginas Markdown, «Ver en el mapa» usaba siempre el ancla de la página (p. ej. 3,4 Ma en *afarensis*) aunque la fecha consultada (3,2 Ma) estuviera dentro de su intervalo; ahora conserva la fecha consultada y solo recurre al ancla o al inicio cuando la fecha queda fuera.
- Pruebas de navegador: espera por defecto de las aserciones subida de 5 s a 20 s (`expect.timeout` en playwright.config.ts) para absorber la lentitud del WebGL por software en las máquinas de integración continua, causa de los fallos intermitentes «#play aria-busy».
- Validación completa: las 164 pruebas de navegador (salvo el barrido anual) en local, 163 aprobadas y la restante corregida y reprobada; 432 pruebas unitarias.

## 0.71.0 · 22 de noviembre de 2026

- Enciclopedia P09-A1 a A3 · 24 fichas de linaje humano (≈ 80.700 palabras) en `enciclopedia/humanidad/linajes/`, que sustituyen a las heredadas con el mismo id `hominin-…` y conservan al final el árbol evolutivo y el comparador:
  - A1 · Primeros homininos: *Sahelanthropus*, *Orrorin*, *Ardipithecus kadabba* y *ramidus*, *Australopithecus anamensis* y *afarensis*.
  - A2 · Diversidad australopitecina: *bahrelghazali*, *deyiremeda*, *Kenyanthropus platyops*, *africanus*, *prometheus*, *garhi*, *sediba* y el *Australopithecus* de Ledi-Geraru.
  - A3 · Parántropos y *Homo* temprano: *Paranthropus aethiopicus*, *boisei* y *robustus*; *Homo* de Ledi-Geraru, *habilis*, *rudolfensis*, *gautengensis*, *ergaster*, *erectus* y *georgicus*.
- Corregido: el comparador de dos linajes (`#human-compare-b`) desaparecía de las fichas al sustituir el esquema heredado por el árbol en 0.70.0, lo que hacía fallar la prueba «Lucy opens an illustrated lineage article…» del despliegue. La prueba del árbol comprueba ahora también el comparador.

## 0.70.0 · 21 de noviembre de 2026

- Enciclopedia P09-0 · Árbol evolutivo interactivo de los homininos (`:::componente arbol-homininos [clave]`, src/encyclopedia/hominin-tree.ts): los 39 linajes de `public/data/human-lineages.json` en un eje de 7 Ma a hoy, agrupados por género, con escala logarítmica o lineal, filtro de propuestas discutidas, cuatro flujos génicos documentados por ADN antiguo y clic para abrir cada ficha. Sustituye al antiguo esquema «hominin-timeline» de las 39 fichas de linaje y de los temas humanos, resaltando el linaje de la ficha abierta.
- La rama Humanidad del índice se subdivide por subcarpeta: especies y linajes, procesos, yacimientos y tecnologías de la piedra (preparada para P09-A…D).
- Prueba de navegador nueva `tests/browser/hominin-tree.spec.ts`.

## 0.69.0 · 18 de noviembre de 2026

- Enciclopedia P08 · Procesos transversales y bestiario: 96 páginas nuevas (≈ 259.000 palabras). 14 síntesis en la rama nueva «Procesos y síntesis» (tectónica de placas, extinciones masivas, glaciaciones de Pongola a hoy, supercontinentes, grandes impactos, nivel del mar, historia de la atmósfera, océanos, fósiles y tafonomía, indicadores paleoclimáticos, biodiversidad, escala del tiempo geológico, incertidumbre y neblina orgánica arcaica); 11 sustituyen a sus artículos heredados.
- Bestiario de la vida pasada: 82 fichas de especie (Ediacárico a Pleistoceno), cada una con ficha lateral, mapa de yacimientos e imagen libre propia; rama propia en el índice, subdividida por eras.
- Componente interactivo `tectonica-placas`: cortes animados de dorsal, subducción, colisión continental, falla transformante y punto caliente, con explicación y ejemplos por modo (textos en i18n).
- Las tablas de la enciclopedia admiten enlaces `[[id|texto]]` en sus celdas.
- Corregido el aviso `ExperimentalWarning: localStorage is not available` de Node 26 en las pruebas: el acceso al almacenamiento pasa por `browserStorage()`, que solo lo toca en el navegador.

## 0.68.0 · 17 de noviembre de 2026

- Enciclopedia P07 · Cenozoico completo: 47 páginas nuevas (≈ 167.200 palabras): la era; Paleógeno, Neógeno y Cuaternario con sus 7 épocas y 24 edades (las 35 unidades ICS del Cenozoico con página propia); temas radiación de los mamíferos, cetáceos, máximo térmico del Paleoceno-Eoceno (sustituye al artículo heredado `petm`), glaciación antártica, Himalaya, crisis salina del Messiniense, istmo de Panamá, praderas C4, ciclos de Milankovitch, glaciaciones del Pleistoceno, extinción de la megafauna y Antropoceno. 45 imágenes nuevas sin repeticiones; `paleogene` y `neogene` redirigen a las páginas nuevas.
- Las unidades geológicas con monografía propia conservan al final los esquemas y laboratorios interactivos de su artículo temático (gráfico climático, laboratorio de CO₂ de los sondeos de hielo en el Cuaternario…), que antes desaparecían al sustituirse el texto.

## 0.67.0 · 17 de noviembre de 2026

- Enciclopedia P06 · Mesozoico completo: 57 páginas nuevas (≈ 224.600 palabras): la era; Triásico, Jurásico y Cretácico con sus 8 series y 30 pisos (las 42 unidades ICS del Mesozoico con página propia); temas origen de los dinosaurios, dinosaurios, origen de las aves, pterosaurios, reptiles marinos, mamíferos mesozoicos, angiospermas, extinción del Triásico-Jurásico, recuperación triásica, episodio pluvial del Carniense, evento anóxico del Toarciense, eventos anóxicos oceánicos del Cretácico, ruptura de Pangea, Trampas del Decán y el impacto de Chicxulub y la extinción K-Pg (sustituye al artículo heredado `kpg`). 66 imágenes nuevas sin repeticiones; `triassic`, `jurassic` y `cretaceous` redirigen a las páginas nuevas.

## 0.66.0 · 17 de noviembre de 2026

- Internacionalización preparada (fase PX2, primera parte): nueva carpeta raíz `i18n/` con `idiomas.json` (español como base y once idiomas previstos: catalán, inglés, francés, alemán, portugués, italiano, chino, japonés, hindi, ruso y árabe) y `i18n/es/` con todos los textos de la interfaz en seis archivos (interfaz, fichas, historia, tierra, enciclopedia, acerca; 1.312 textos). El código los pide con `tx('modulo.clave')`; los datos variables van como `{marcadores}`.
- `src/i18n.ts`: detecta el idioma del sistema (o el elegido, guardado en el navegador), usa el español como reserva para las claves que falten, fija `lang` y la dirección de escritura del documento. Los formatos de números y fechas y la voz de lectura siguen el idioma activo.
- `i18n/README.md` explica cómo traducir la carpeta de una vez y qué contenidos quedan fuera (enciclopedia, datos, nombres). `npm run i18n:check` (y una prueba unitaria) comprueban que no falte ninguna clave y, en cada idioma traducido, claves que faltan o sobran y marcadores perdidos.

## 0.65.0 · 15 de noviembre de 2026

- Renovación gráfica del tiempo profundo (de la acreción a 7 Ma; el atlas posterior no cambia): nuevo motor `src/deep-render.ts` que pinta en la GPU (WebGL2, un sombreador de fragmentos) la textura que MapLibre proyecta en el globo y en el plano. Océano de magma animado con balsas de corteza, grietas incandescentes e impactos; corteza en enfriamiento con lagos de lava; relieve sombreado con cordilleras, cinturones climáticos por latitud (selva ecuatorial, desiertos subtropicales, templado, tundra), capas rojas tras la Gran Oxigenación y vegetación desde el Ordovícico; mares con fosas, plataformas y bajíos turquesa; mantos de hielo con relieve y grietas, banquisa fragmentada, Tierra bola de nieve con hielo azul tropical y fracturas, glaciares regionales; volcanes activos en el Hádico y el Eoarcaico. Las costas fechadas, la extensión del hielo, la calima arcaica y la variante ferruginosa siguen saliendo de los datos del atlas.
- Globo en el espacio (`src/deep-space.ts`): fondo estrellado que se desplaza al girar, halo atmosférico con color por época (resplandor del magma, calima anaranjada, azul tras la oxigenación, blanco azulado en las glaciaciones globales) y sombreado esférico. Los casquetes más allá de 85° de latitud se rellenan con el color real del borde de la textura (antes quedaba un disco plano).
- Resolución adaptada al equipo: 4096 px en escenas fijas y 2048 px en las animadas con GPU de sobremesa, 2048 px en móviles, 1024 px sin animación con trazado por software; si WebGL2 no está disponible se usa el pintor anterior. Ajuste manual opcional con `localStorage['historicmap-deep-size']`. Se respeta «movimiento reducido».

## 0.64.0 · 14 de noviembre de 2026

- Enciclopedia P05 completada (tercera entrega): 38 páginas nuevas (≈ 130.700 palabras): Carbonífero con sus subperiodos Misisípico y Pensilvánico, 6 series y 7 pisos; Pérmico con sus 3 series y 9 pisos; temas bosques del carbón, oxígeno del Carbonífero y artrópodos gigantes, origen de los amniotas, Pangea, glaciación del Karoo, sinápsidos del Pérmico, extinción del Capitaniense, Trampas Siberianas y la Gran Mortandad del Pérmico-Triásico. 46 imágenes nuevas sin repeticiones; `carboniferous` y `permian` redirigen a las páginas nuevas. Todas las unidades ICS del Paleozoico (79) tienen ya página propia.

## 0.63.0 · 14 de noviembre de 2026

- Enciclopedia P05 (segunda entrega): 30 páginas nuevas (≈ 97.400 palabras): Silúrico con sus 4 series (incluido Přídolí) y 8 pisos; Devónico con sus 3 series y 7 pisos; temas eventos del Silúrico (Ireviken, Mulde, Lau…), conquista de los continentes, peces con mandíbula, origen de los tetrápodos, eventos globales del Devónico, plantas y CO₂, y extinción del Devónico tardío. 26 imágenes nuevas sin repeticiones; `silurian` y `devonian` redirigen a las páginas nuevas.
- Cronología ICS: el generador `prepare-earth-chronology.py` reconoce Přídolí (serie y piso a la vez en el RDF) y corrige el techo del Ludlow (422,7 Ma), con lo que la prueba de reproducibilidad vuelve a pasar en CI.

## 0.62.0 · 8 de noviembre de 2026

- Enciclopedia P05 (primera entrega): 32 páginas nuevas (≈ 90.600 palabras): era Paleozoica; Cámbrico con sus 4 series y 10 pisos; Ordovícico con sus 3 series y 7 pisos; temas explosión cámbrica, Lagerstätten cámbricos (Chengjiang, Burgess, Sirius Passet, Emu Bay, Kaili, Orsten), eventos oceánicos cámbricos (BACE–HERB), Gran Evento de Biodiversificación del Ordovícico y extinción del Ordovícico-Silúrico. 44 imágenes nuevas de Commons, sin repeticiones. `cambrian` y `ordovician` redirigen a las páginas nuevas.
- Cronología ICS: restituida la serie Přídolí (422,7–419,62 Ma), que la importación había fundido con el Ludlow (que ahora termina en 422,7 Ma); 178 unidades.
- Índice lateral: «Conceptos y procesos» (antes «Tierra y vida · artículos temáticos») con subapartados Precámbrico/Fanerozoico/Cuaternario; Planeta Tierra, Clima y La vida subdivididos por eón o era; nuevo desplegable «Archivo audiovisual» por eras. El buscador incluye siempre el archivo audiovisual (se retira la casilla).
- Tema de mañana: la enciclopedia usa tonos de papel propios (cabecera, índice y lectura diferenciados) con títulos en tinta oscura; tarde y noche separan ligeramente el índice del texto. Fondo del mapa de mañana algo menos claro.

## 0.61.0 · 8 de noviembre de 2026

- Enciclopedia P04 · Proterozoico: 28 páginas nuevas (≈ 95.600 palabras; entre 2.470 y 5.000 por página): eras Paleoproterozoico, Mesoproterozoico y Neoproterozoico; periodos Sidérico, Riácico, Orosírico, Estatérico, Calímico, Ectásico, Esténico, Tónico, Criogénico y Ediacárico; temas Gran Oxigenación, glaciaciones huronianas, diques y grandes provincias ígneas, excursión Lomagundi-Jatuli y evento Shunga, impactos de Yarrabubba, Vredefort y Sudbury, reactores de Oklo, Columbia/Nuna, «mil millones aburridos», eucariotas, sexo y multicelularidad, Rodinia, Tierra bola de nieve, biota de Ediacara, origen de los animales y anomalía de Shuram. Los artículos heredados `oxygenation`, `matachewan`, `oklo`, `eukaryotes`, `rodinia`, `ice` y `ediacaran` se sustituyen conservando su id (y sus laboratorios); `proterozoic` redirige a la página del eón.
- 35 imágenes nuevas de Commons con licencia libre y crédito, sin repeticiones; los PNG/SVG con fondo transparente se muestran sobre fondo claro.
- Lectura en voz alta: reproductor fijo y centrado en la cabecera (párrafo anterior, reproducir/pausa con ecualizador animado, párrafo siguiente, detener y ajustes discretos de velocidad y voz, recordados en el navegador). La voz pronuncia «millones de años» por Ma, «miles de millones de años» por Ga, cifras con punto de millar como enteros, intervalos («a»), ±, ≈, fórmulas (CO₂, CH₄), métodos (U-Pb) y unidades habituales, sin cambiar el texto visible.
- Compilador: los bloques `:::` ya no confunden una lista tras una línea en blanco con un componente desconocido.

## 0.60.0 · 8 de noviembre de 2026

- Revisión completa del contenido de P01–P03 a petición del propietario (nivel universitario, mínimo 1.500 palabras por página): las 37 páginas pasan de ≈ 25.000 a ≈ 127.500 palabras (entre 1.900 y 7.800 por página), con etimología, definición de límites (GSSP/GSSA y propuestas de la ICS), localidades y formaciones, métodos (geocronología, isótopos, modelos), historia de la investigación, debates, tablas, gráficos calculados o rotulados como esquema, mapas y líneas de tiempo. DOI contrastados con Crossref; corregidos DOI erróneos heredados (Young 1998, Lowe 2014, Condie 2018).
- 79 imágenes de Wikimedia Commons con licencia libre y crédito; cada imagen se usa en una sola página (el compilador lo exige).
- Lectura en voz alta: botón «Escuchar» con la síntesis de voz del navegador (voz española), pausa, parada y velocidad; lee la página entera o desde el texto seleccionado; durante la lectura, pulsar un párrafo salta a él; resalta y sigue el párrafo leído.
- Lector a toda la anchura: la ficha flota dentro del texto en lugar de reservar una columna fija; los párrafos ocupan todo el ancho disponible.
- Las unidades geológicas aún sin monografía ya no muestran un texto de plantilla: indican la fase del plan en que se redactarán y muestran sus datos y su escala.
- El panorama «La Tierra hace…» incluye el texto completo de la unidad geológica vigente.
- El compilador avisa de las páginas con menos de 1.500 palabras; una prueba unitaria exige que no haya ninguna y que no se repitan imágenes.

## 0.59.0 · 7 de noviembre de 2026

- Enciclopedia P03: formación de la Tierra, Hádico y Arcaico. 29 páginas nuevas o reescritas (≈ 18.000 palabras): las seis unidades (Hádico, Arcaico y sus cuatro eras) y 24 artículos temáticos — formación del sistema solar, diferenciación, Theia y la Luna, océano de magma, origen del agua, circones de Jack Hills, bombardeo intenso, campo magnético, interior terrestre, rocas más antiguas, cratones y supercratones, rocas verdes y komatiitas, tectónica arcaica, aire y mar del Arcaico, paradoja del Sol débil, glaciación de Pongola, impactos arcaicos, duración del día, hierro bandeado, primer oxígeno, origen de la vida, LUCA, estromatolitos, metabolismos primitivos y fotosíntesis oxigénica.
- Siete imágenes nuevas de Commons con licencia y crédito; mapas, líneas de tiempo, gráficos (brillo del Sol, duración del día, impactos) y composición atmosférica por era.
- Motor: «Leer completo» de una unidad geológica incluye sus artículos temáticos antes de sus subdivisiones; campo `reemplaza` para retirar artículos heredados duplicados (redirige `hadean` y `archean`); al sustituir el texto de un artículo heredado se conservan sus imágenes, laboratorios y vídeos (Theia, Formación). Panorama de fecha con pasos adaptados a la escala (50 Ma en el Precámbrico remoto) y lectura principal con el texto nuevo.
- El script de imágenes corrige la extensión cuando Commons entrega PNG para un SVG.

## 0.58.0 · 7 de noviembre de 2026

- Enciclopedia P02: escala geológica interactiva que se amplía al pulsar cada unidad (eón → era → periodo → época → edad), con migas y desplazamiento horizontal en pantallas estrechas; sustituye a la escala fija que aplastaba las unidades cortas.
- Biblioteca de componentes desde Markdown: `:::grafico` (líneas, áreas, barras, con tabla de datos), `:::linea-tiempo` proporcional, `:::mapa` de localización (contorno simplificado de Natural Earth generado al compilar), `:::galeria`, `atmosfera` (composición de referencia en una fecha) y diagrama de sucesión de mandatos en las fichas de entidades.
- Integración con el mapa: el nombre de cada dirigente de la ficha abre su página de la enciclopedia, y la ficha ofrece «Historia y dirigentes en la enciclopedia» para la entidad seleccionada.
- Canal de imágenes `scripts/fetch-encyclopedia-media.mjs`: descarga desde Wikimedia Commons solo con licencias libres y registra autor, licencia y fuente en `enciclopedia/medios/creditos.json`; el compilador rechaza imágenes sin crédito, componentes desconocidos y enlaces rotos. Tres primeras imágenes acreditadas.
- Publicación: el paso de despliegue de Pages admite hasta 30 min (el sitio supera 1 GB y agotó el plazo por defecto de 10 min).

## 0.57.0 · 7 de noviembre de 2026

- Enciclopedia P01 (cimientos): nueva carpeta raíz `enciclopedia/` con páginas Markdown + cabecera YAML, guía editorial y plan de 25 fases ([PLAN](enciclopedia/PLAN.md)).
- Compilador `scripts/build-encyclopedia.mjs` sin dependencias: valida cabeceras, identificadores y enlaces internos; genera índice, nombres y fichas de los 12.606 dirigentes, 2.423 entidades y 20.559 mandatos del atlas (fragmentos cargados bajo demanda). Se ejecuta al arrancar Vite; `enciclopedia/_generado/` no se versiona.
- Lector nuevo: índice por ramas con árbol completo de la escala ICS, búsqueda unificada (artículos, unidades, dirigentes y entidades), ficha lateral, migas de pan, «Leer completo» que compone una unidad con todas sus subdivisiones, panorama «El mundo en…» por fecha (unidades vigentes, periodizaciones, dirigentes de todo el mundo ese año, navegación año a año) y fichas automáticas de personas y entidades.
- Componentes visuales iniciales: escala geológica proporcional interactiva, reloj geológico y curva de temperatura fanerozoica. Primeras páginas: portada, guía, escala temporal, Precámbrico y los cuatro eones.
- Contenido heredado de Tierra/ conservado con sus diagramas, fotografías e indicadores; las subdivisiones geológicas ya no repiten el artículo temático de su periodo.

## 0.56.0 · 2 de noviembre de 2026

- Sexta parte: revisión de integración geológica/humana, inventario reproducible de fuentes, relaciones, medios y carencias.
- Corregida la prueba heredada de100.000a.C.: reconoce la hipótesisMIS5c y comprueba un hueco real sin extrapolación; se conserva el límite propio dePaleoMIST.
- Fecha de retorno de la enciclopedia coherente con el contexto válido, capítulo del Cuaternario y seis fotografías fósiles/reproducciones acreditadas.
- Rótulos temporales sin solapamientos, marca1d.C. prioritaria y fuentes glaciales más claras. Corregida una asociación de imagen a un artículo inexistente.
- Ocho gruposCI y barrido anual conservados; comprobación rápida adicional de integridad enciclopédica.


## 0.55.0 · 2026-11-02

- Quinta parte: 49 artículos humanos contextualizados, 39 entradas taxonómicas/poblacionales, 12 fotografías acreditadas, diagramas y comparador de linajes; enlaces desde manchas y yacimientos.
- Dos fases regionales y siete referencias fósiles nuevas; conservadas las66 geometrías y los982 registros originales anteriores. Correspondencias de la lista aportada y revisiones contextuales sin sobrescribir atribuciones originales.
- Doce ventanas glaciales boreales de Batchelor2019 con36 recursos comprimidos sin pérdida, variantes mínima/máxima optativas, límites de cobertura y selección automática sin extrapolar; PaleoMIST mantiene precedencia.
- Compuesto antártico de1.901 observaciones deCO₂: edad real del gas, ppm, porcentaje y error; gráfica y explorador interactivos. No se deducen temperatura global, paleocostas o guerras de esas referencias.
- Conservación de países/culturas y ocho gruposCI más barrido anual independiente. [Alcance y pendientes](docs/EARTH-HUMANITY-0.55.md); parte6 pendiente de encargo.

## 0.51.1 · 2026-11-01

- Corregida una expectativa antigua de navegador: Capas contiene el selector de hielo; gobierno, alianzas y tema cartográfico siguen exclusivamente en Filtros. Se mantienen las comprobaciones de opciones positivas, cero resultados, foco y móvil.
- La comprobación de retratos del mismo recorrido abre Autoridades, desplaza la imagen al área visible y espera su decodificación, conservando la exigencia de que cargue correctamente.
- La reproducción científica con --check conserva la versión declarada de cada recurso durante actualizaciones exclusivas del producto. Sin modificaciones de datos, controles, apariencia o reparto de pruebas.

## 0.51.0 · 2026-11-01

- Áreas regionales humanas fechadas hasta7Ma,35 entradas taxonómicas/genéticas (24 con áreas,11 alternativas), franjas de coexistencia, selección compartida y fichas persistentes. Conservados los2820 registros previos;1000 intervalos adicionales con fuentes y propietarios canónicos naturales.
- CostasCAO2024 de2–7Ma sin simplificar, navegación prehistórica y filtros ampliados; fuentes y ventanas de incertidumbre explícitas. No se inventan rutas, fronteras biológicas o guerras.
- Hielo automático según variación del modeloPaleoMIST y elección manualauto/on/off. Contexto climáticoLR04 hasta5,32Ma, sin extrapolar contornos fuera de80ka.
- Océanos azules claro/intermedio/oscuro; interfaz cálida de tarde conservada y noche sin cambios. Ocho grupos de navegador y barrido anual independiente conservados.

## 0.50.2 · 2026-11-01

- La validación de navegador pasa de cuatro a ocho grupos independientes, con un navegador por grupo. El barrido anual1789–presente tiene una ejecución adicional propia, excluida de esos grupos para evitar duplicados. Todas las pruebas siguen siendo obligatorias; se reutiliza la compilación común y se mantiene la recopilación temprana.
- Actualizada la prueba de descargas culturales atrasadas:10001a.C. conserva las evidencias arqueológicas incorporadas; una fecha geológica permanece sin regiones. Se comprueban respuesta completada, fecha vigente y reutilización de la descarga.
- Datos y comportamiento de la aplicación conservados.

## 0.50.1 · 2026-11-01

- Corregidas las importaciones JSON de cronología e índice glacial para la carga ESM de Node usada por Playwright. El fallo impedía recopilar las pruebas de los cuatro grupos antes de abrir el navegador.
- Quality comprueba la recopilación completa de pruebas inmediatamente después de instalar dependencias, antes de verificar datos, ejecutar las baterías y compilar. Mantiene los cuatro grupos y los requisitos de publicación.
- Conservados todos los datos y la ampliación hasta100000a.C.

## 0.50.0 · 2026-11-01

- Consulta prehistórica hasta 100000 a. C.: 803 referencias de yacimientos o conjuntos y 2820 registros fechados o contextuales, sin fronteras biológicas ni ocupaciones continuas supuestas.
- PaleoHumans1.0.0:417 ventanas de contexto del Paleolítico superior, resultados sin calibrar conservados y cinco contextos inciertos sin fecha inventada. Continuidad de las referencias hasta9751a.C., cruzando10000 junto a las áreas culturales anteriores.
- Atribuciones humanas, culturas materiales, niveles, fuentes y fechas en fichas persistentes. Puntos inicialmente visibles y filtro de grupos humanos; controles culturales independientes de la cartografía política.
- Navegación de 100 años por paso en el nuevo tramo, conservando fecha exacta, consulta anual desde 10000 a. C. y continuidad civil sin cero.
- PaleoMIST: 92 originales y 23 muestras hasta 80000 BP1950; la capa se detiene antes de ese límite. Costas contemporáneas de referencia, sin extrapolación del hielo o rutas inventadas.
- Conservación de 20559 mandatos y 10304 fases culturales anteriores, con procedencia canónica dentro de Países y Tierra.

## 0.49.0 · 2026-11-01

- Consulta hasta 10.000 a. C. con 4.000 fechas civiles adicionales, 20 expedientes arqueológicos y 27 referencias culturales fechadas. Conservación del contenido posterior y continuidad 8001/8000 y 6001/6000, sin Estados o gobernantes supuestos.
- Capa opcional de mantos de hielo PaleoMIST 1.0: 24 originales geográficos y seis muestras cada 2.500 años. Polos, antimeridiano y solapamientos internos resueltos; fecha real del modelo en leyenda y Fuentes. Costas contemporáneas explícitas, sin paleocostas inferidas.
- BP1950, b2k y cronología civil diferenciados; fases del Holoceno y contexto del Pleistoceno. Catálogo natural en Tierra; datos de entidades en Países, con expedientes arqueológicos por tramo.
- Pruebas de cronología, conservación, fuentes originales, geometría polar y cargas tardías. Registros de entrega y pendientes actualizados. Sin cambios en el proceso de publicación ni espera de Actions.

## 0.48.0 · 31 de octubre de 2026

- Consulta de 6000–3001 a.C. con 22 referencias arqueológicas y 66 grupos regionales originales/94 fases. Cronologías, fuentes y decisiones en las carpetas de cada entidad.
- Contextos arqueológicos legibles en la ficha, validados al compilar y separados de la lista de episodios anuales. Vistas genéricas integradas en sus propietarios sin perder referencias.
- Tres componentes políticos originales desde 3400; no polígonos estatales, gobernantes o símbolos nacionales ficticios antes de su evidencia.
- Cerámica cardial recuperada de metadatos con nombre vacío; rótulos anacrónicos y antecedentes culturales cualificados. La referencia de 8000 se identifica como contexto anterior, sin presentar5000 como mapa de 6000.
- Nuevo contrato de arqueología separado de los lotes políticos de 400 años. Yacimientos distinguidos de capitales; catálogo respeta la carpeta propietaria de los nuevos dossiers.
- Ruta documentada para dispersión de homininos, paleoclima, tectónica, vida, extinciones y formación terrestre.10000 a.C. sigue como siguiente encargo.

## 0.47.0 · 31 de octubre de 2026

- Consulta anual de 3000–2001 a. C., en tres tramos acotados. Egipto temprano y Reino Antiguo, ciudades sumerias, Akkad, Ur III y transiciones posteriores, con 39 dossiers, 50 ventanas de autoridades, notas de secuencias sin fechas suficientes, centros y contexto.
- 25 grupos culturales originales y 31 fases, conservando el contenido posterior. Referencia de 3000 identificada como tal; no se utiliza el mapa de 2000 para fechas anteriores.
- 42 imágenes candidatas inspeccionadas: 23 representaciones adoptadas, 19 descartadas, 22 archivos nuevos. Figuras fundacionales de Ur-Nammu y Shulgi sustituyen inscripciones sin retrato. Originales y créditos por entidad.
- Nombres dinásticos de la fuente corregidos por fases sin alterar sus geometrías; continuidad de autoridades 2001/2000 y ausencia de año cero. Colores editoriales diferenciados para Akkad y Ur III.
- El catálogo incluye todos los recursos a. C. registrados, evitando omisiones por mantener una lista manual de nombres de archivos.

## 0.46.0 · 30 de octubre de 2026

- Consulta anual de 2000–1001 a. C., con tres tramos internos, sucesiones y centros de la Edad del Bronce, contextos e imágenes atribuidas. Continuidad de las identidades al cruzar 1001/1000.
- Pueblos y áreas culturales conservados junto a la cartografía política; 113 grupos originales nuevos y 146 fases. Rótulos regionales anacrónicos interpretados expresamente como referencias y antecedentes.
- 125 candidatos visuales revisados: 52 adoptados con explicación y 73 descartados. Originales, créditos, decisiones y datos en las carpetas de cada entidad.
- Tonos editoriales diferenciados para Shang, Zhou y Hatti; dependencias fechadas y distinción entre redes palaciales y Estados unificados.
- [Fuentes y límites](docs/RESEARCH-bc2000.md), [inventario](docs/PERIOD-INVENTORY-bc2000.json) y [validación](docs/DELIVERY-0.46.0.md).

## 0.45.0 · 30 de octubre de2026

- Consulta anual1000–601a.C., autoridades ycentros documentales, contextos, culturas yreferencias de conflictos. Se conservan las fases posteriores.
- Tonos culturales estables para áreas importadas con gris inicial; rótulos españoles yoriginales buscables, con traducciones enlas carpetas de entidades.
- Revisión visual de98 candidatos,50 imágenes aceptadas y48 rechazadas con atribuciones explícitas.
- Precisión documental de fechas vitales, corrección de atribución saíta ycatálogo sincronizado antes de comprobar. [Método ylímite](docs/RESEARCH-bc1000.md), [comprobaciones](docs/DELIVERY-0.45.0.md).

## 0.44.1 · 29 de octubre de 2026

- Sincroniza la ficha generada de Qin y su índice con las dos etapas de Huiwen: señor antes de325a.C. y rey desde325. No se revierten los datos corregidos de0.44.0.
- El registro de revisiones actualiza también el catálogo de entidades y propaga sus errores. Las pruebas siguen ejecutándose sobre los archivos registrados antes de compilar la aplicación.
- Regresión aislada de catálogo desactualizado, conservación de carpeta, segunda ejecución sin diferencias y propagación de errores. Se conserva la comparación exhaustiva entre fichas e identidades.
- Se mantiene toda la ampliación600–301a.C. y los cuatro grupos de navegador. El propietario comprueba el despliegue.

## 0.44.0 · 29 de octubre de 2026

- Consulta anual600–301a.C.:87 dossiers,427 registros de autoridades,296 componentes originales,47 centros,44 contextos y34 puntos de conflictos.
- Sucesiones y títulos en Persia, Egipto, Macedonia, ciudades griegas, Roma, China Zhou, Magadha,Lanka yKush; claves propias y cualificación de identidades anacrónicas. Las dependencias e incorporaciones cambian la cartografía principal.
- 223 originales culturales de700,500 y400a.C.;290 fases nuevas y9.862 totales.700 se consulta como referencia histórica anterior, sin inventar un mapa600. Se conservan literalmente las9.572 fases previas.
- 107 candidatos visuales inspeccionados:66 aceptados y41 apartados. Atribuciones, bustos, grabados y esculturas retrospectivas identificados. No convertir dioses monetarios, mapas, escenas colectivas u homónimos en retratos personales.
- La geometría compilada retiene la clave propietaria como identidad inicial, evitando asignaciones del catálogo basadas en Wikidata compartido. Adquisición admite ventanas explícitas de hasta300años, con límites de era y ausencia de año cero intactos.
- Registros sin polígono propio accesibles desde centros documentales. El agregado macedonio315–308 se declara como síntesis de varios poderes; no se inventan fronteras para ocultarlo. Fuentes, conservación, pruebas y pendientes en DELIVERY-0.44.0 y RESEARCH-bc600.

## 0.43.0 · 29 de octubre de2026

- Consulta anual300–201a.C.:83 dossiers,220 registros de autoridades,319 componentes políticos originales,30 centros,23 contextos y17 referencias regionales de conflictos.
- Estados antiguosWei,Qi,Yan,Zhao yLu separados deidentificadores de entidades posteriores. Los reinos de la particiónChu–Han tienen claves propias; corrección de homónimosZhangEr yShenYang.
- Qin distingue reino y título imperial desde221; Lu se incorpora aChu ySong aQi. Reorganizaciones helenísticas, magistraturas republicanas, Maurya,Lanka yKush con cargos y cronologías documentados.
- 73 originales culturales,70 fases nuevas y9.572 acumuladas; conservación literal de las9.502 anteriores, con continuidad y fechas decontextos históricos explícitas.
- 83 candidatos visuales inspeccionados:49 aceptados y34 apartados, más dos alternativas identificadas. Ashoka en panel inscrito deKanaganahalli conGODL; efigie dePtolomeoIII emitida porIV. Dioses, emisores, personajes representados y obras retrospectivas se distinguen.
- Continuidad con200: Kalinga bajoMaurya hasta185 y vinculación nominalHan deMinyue desde202. Nicomedia,Chang’an yDongye respetan sus fechas deconsulta.
- Comprobaciones, fuentes, carencias e integridad documentadas. Se mantienen las cuatro máquinas deCI y la comprobación de publicación por el propietario.

## 0.42.0 · 29 de octubre de 2026

- Consulta anual de 200–101 a. C.: 57 dossiers, 180 registros de autoridades, 158 componentes políticos originales, 32 centros, 23 contextos y 12 referencias regionales de conflictos.
- República romana, sucesiones ptolemaicas y Han, distritos y provincia macedonios, anexiones de Cartago/Pérgamo y cronologías arsácidas diferenciados. Autoridades colectivas y fechas discutidas expresas.
- 85 originales culturales conservados y 98 fases nuevas; las comunidades y contextos históricos siguen disponibles tras los cambios políticos. Se mantiene el enlace entre eras sin año cero.
- 115 candidatos visuales inspeccionados: 85 aceptados y 30 apartados. Aníbal recibe una representación artística identificada de Slodtz; monedas, medallones y esculturas conservan atribuciones y límites. Formato compacto habitual de las fichas.
- Fechas de episodios con día y mes de dos cifras: Borodinó muestra 07/09/1812. Se conserva el formato propio de los mandatos.
- Auditoría de los mismos 1.006 años optimizada mediante comparación de valores y reutilización de nombres normalizados, sin retirar controles ni ampliar el tiempo máximo. Pruebas de versión y límite temporal ligadas a los datos vigentes.
- Conservación, reproducibilidad y carencias documentadas. Se mantienen las cuatro máquinas de CI; el propietario comprueba la publicación.

## 0.41.0 · 28 de octubre de2026

- Consulta anual100–1a.C., con63 dossiers,172 cargos y190 componentes originales;30 centros,24 contextos y ocho referencias regionales de conflictos.
- Fechas civiles firmadas, orden cronológico correcto y salto directo1a.C./1d.C. en navegación y reproducción, sin año cero. Diez registros complementarios de autoridades conservan continuidad entre eras.
- República romana y Principado desde27a.C.; transiciones ptolemaicas, Han, herodianas y arsácidas diferenciadas, con títulos y cronologías discutidas explícitos.
- 157 fases culturales nuevas y163 originales nominales conservados. Todos los contextos y geometrías culturales de1a.C. enlazan con1d.C.; los ámbitos históricos no son población contemporánea acreditada.
- 111 candidatos de imagen inspeccionados:92 aceptados,19 apartados y alternativa monetaria identificada para Musa. Caras individuales, atribuciones y representaciones posteriores conservan créditos y límites.
- Colores, relación herodiana con Roma y clasificación regional armonizados entre eras; diferencias de contorno de la fuente registradas, sin interpolar geometrías.
- Conservación, carencias y comprobaciones documentadas; se mantienen las cuatro máquinas deCI y el envío sin esperar publicación.

## 0.40.0 · 28 de octubre de 2026

- Consulta anual1–99d.C., sin año cero;62 dossiers y141 componentes políticos originales,30 centros y20 contextos.
- Transiciones Han–Xin–Han, Dayuan identificado frente al enlace Yuan medieval y rebelión Trưng40–43 diferenciadas de las fechas de sus contornos de origen.
- 68 fases culturales nuevas, con referencia espacial explícita de1a.C.;79 dossiers originales conservados, incluidas remisiones y exclusiones documentadas.
- 64 candidatos visuales inspeccionados,57 aceptados y siete apartados. Caras monetarias, medallones retrospectivos y atribuciones diferenciados.
- Corregida la prueba de publicación que esperaba el snapshot100 al consultar117: se exige ahora el mapa anual117 dibujado y la fecha cargada. Se mantienen cuatro máquinas enCI.
- Fuentes, carencias, conservación y comprobaciones locales documentadas.

## 0.39.0 · 28 de octubre de 2026

- Consulta anual100–199:55 dossiers,111 cargos,126 componentes políticos originales,24 centros y18 contextos. Se conservan todas las etapas posteriores.
- 71 referencias culturales nuevas de83 dossiers originales;10 remisiones políticas y dos exclusiones cronológicas documentadas. No se equipara conquista con desaparición de comunidades.
- 60 candidatos visuales inspeccionados,50 aceptados y diez apartados. Pertinax usa denario identificado; textos epigráficos, escenas colectivas y atribuciones insuficientes quedan fuera de los retratos.
- Títulos de césar, augusto y pretendiente diferenciados; regencias Han y cronologías pontificias alternativas explícitas. Realeza parta separada de los cargos de Armenia/Osroene y Kushan con fechas numismáticas aproximadas.
- Lector de mandatos admite años anteriores a100 y separador snds, sin usar fechas de vida, confundir a.C./d.C. ni aceptar el año cero.
- Fuentes, carencias, conservación e integridad documentadas por entidad; CI mantiene sus cuatro máquinas.

## 0.38.0 · 28 de octubre de 2026

- Consulta anual200–299 con67 dossiers,186 cargos,153 componentes políticos originales,29 centros y25 contextos; crisis romana, títulos y regencias de los Tres Reinos y transición arsácida/sasánida diferenciados.
- 58 fases culturales nuevas sin retirar las anteriores;69 originales nominales conservados, con remisiones políticas y una exclusión anacrónica explícita.
- 118 candidatos de imagen inspeccionados:112 aceptados y seis descartados. Caras monetarias elegidas, grabados retrospectivos y piezas póstumas identificados; no glifos como retratos.
- Continuidad de colores romanos399/400 corregida: Occidente púrpura rojizo y Oriente violeta; el cambio de cobertura no representa un cambio de régimen.
- Siete fases militares de Afganistán e Irak: intervención soviética, coalición/ISAF, apoyo posterior, invasión y ocupación de Irak, y presencia tras la transferencia de autoridad. Tonos y franjas nacionales de referencia con límites explícitos, conservando identidades propias.
- Regla temporal con marcas habituales cada50años desde el primer siglo, marca explícita del año1 y navegación manual anual; se omite el año cero y se mantiene el zoom adaptable.
- Fuentes, conservación y carencias por entidad; no se inventan banderas, frentes locales ni cronologías completas donde falta evidencia.

## 0.37.0 · 28 de octubre de 2026

- Ampliación anual300–399 con232 componentes políticos originales y58 referencias culturales nuevas; se conservan todas las fases posteriores.
- Gobiernos romanos compartidos, dignidades de augusto/césar, cortes de395, sucesiones Jin y distintos poderes de los Dieciséis Reinos diferenciados. Las sedes documentales no inventan fronteras.
- Autoridades con fechas, alternativas cronológicas y testimonios;41 centros,20 contextos y cinco referencias regionales de conflictos.
- Revisión visual de81 candidatos:73 aceptados y ocho apartados. Los glifos, inscripciones y atribuciones inadecuadas no se usan como retratos.
- Imágenes completas en las fichas y encuadre no destructivo de la cara elegida en monedas pareadas. Revisión adicional de44 imágenes ya publicadas, respetando rechazos anteriores.
- ValentinianoIII con cabeza identificada por el Louvre, fecha425–450 y restauraciones modernas explícitas; se conservan los originales y créditos.
- Lector de fechas compatible con «no wrap»; las dignidades subordinadas se distinguen del reinado posterior. Se mantiene la publicación distribuida en cuatro máquinas.

## 0.36.0 · 28 de octubre de 2026

- Entrega conjunta: ampliación 400–499 y correcciones de las dos publicaciones anteriores.
- 305 componentes políticos originales, 82 dossiers de periodo y 227 registros de autoridades; 42 centros documentales, 20 contextos y siete referencias de conflictos.
- Cortes romanas, Italia de Odoacro, sucesiones chinas, restauraciones sasánidas y testimonios mayas diferenciados, sin inventar fronteras ni fechas de reinado.
- 70 referencias culturales nuevas; originales, fases anteriores y decisiones conservados. Política y culturas siguen activadas inicialmente y disponibles por separado.
- 111 candidatos visuales inspeccionados: 91 aceptados y 20 rechazados, con pies, licencias y carencias documentadas por entidad.
- Pruebas corregidas para consultar la cobertura temporal real, sin ocultar culturas ni restaurar mapas obsoletos para satisfacer expectativas antiguas.
- Pruebas de navegador repartidas entre cuatro máquinas y compilación reutilizada en la publicación automática, con comprobación de la revisión exacta. Sin eliminar pruebas ni esperar el despliegue remoto.

## 0.35.0 · 28 de octubre de 2026

- Consulta y reproducción anual desde 500: 270 componentes políticos originales y 73 referencias culturales nuevas, conservando los datos posteriores.
- Sucesiones chinas del norte y sur, proclamación Sui y reunificación diferenciadas; cortes documentales disponibles cuando falta un contorno político coincidente.
- César, regencia y reinado imperial diferenciados; restauraciones sasánidas, autoridades rivales y fases de Amalasunta revisadas.
- Cortes propias de Palenque, Tikal y Copán bajo la referencia regional maya, sin atribuirles fronteras inventadas; secuencia de Copán contrastada con investigación epigráfica.
- 43 centros fechados, 21 contextos y ocho referencias de conflictos. Dos etiquetas culturales anacrónicas apartadas de la visualización conservando sus originales.
- Revisión visual de 125 candidatos: 95 aceptados y 30 rechazados; fechas, pies, licencias y carencias registrados en la carpeta de cada entidad.

## 0.34.0 · 28 de octubre de 2026

- Ampliación anual600–699 con425 componentes políticos originales y68 referencias culturales nuevas, conservando las fases posteriores.
- Sui/Tang, fin sasánida, primeros califatos, poder rival zubayrí, regencias y cambios de dinastía diferenciados; desfases espaciales de la fuente explícitos.
- Sedes documentales para poderes sin polígono disponible; no se inventan fronteras. Los contornos políticos heredados permiten leer las culturas subyacentes.
- Dos reinados deKōgyoku/Saimei, realeza merovingia y mayordomías, cronologías discutidas y testimonios aislados distinguidos.
- Revisión visual de135 candidatos:98 aceptados y37 rechazados, con originales, licencias y pies por entidad. Símbolos y carencias pendientes documentados.
- Lector de mandatos compatible conA.D./C.E. y rangos explícitos con «to», sin derivar cargos de fechas personales.

## 0.33.0 · 28 de octubre de 2026

- Consulta y reproducción anual700–799:359 componentes políticos originales y99 referencias regionales adoptadas, con originales y decisiones dentro de cada entidad.
- Cartografía política y Pueblos y áreas culturales disponibles en Capas y Filtros, sincronizados e independientes. Ambos activados inicialmente; preferencias conservadas al cambiar de año/proyección, fichas abiertas y búsqueda acorde con las áreas visibles.
- Fondo continental neutro al ocultar ambas cartografías, también en el mapa actual. Rótulos y contornos de selección se ocultan junto a su cartografía; relieve, ciudades y conflictos mantienen sus controles.
- Reyes merovingios/carolingios y mayordomos separados, sucesión omeya-abasí, Zhou de Wu Zetian y restauración Tang, regencias bizantinas y dos reinados de Kōken/Shōtoku diferenciados.
- Fuente regional700 con anacronismos explícitos: ámbitos posteriores a Sui, sasánidas, Goguryeo y Baekje; dos lagos conservados en el inventario sin presentarlos como pueblos.
- Revisión de117 candidatos visuales:76 adoptados y41 descartados. Insignias, cronologías discutidas y carencias pendientes documentadas; no se inventan banderas ni retratos contemporáneos.
- Compilador de resoluciones con acumulación ordenada en memoria para evitar reescribir el mismo recurso por cada entidad; conservación e idempotencia verificadas en 213 archivos.

## 0.32.0 · 28 de octubre de 2026

- Navegación y reproducción anual800–899,528 componentes políticos originales y85 referencias culturales/regionales, sin retirar las fases900–2027.
- Referencia carolingia843–849 diferenciada del reparto deVerdún; tres coronas consultables mediante centros fechados sin adelantar las fronteras850.
- Autoridades fechadas, centros históricos, contextos y conflictos del sigloIX; coronas carolingias, regencias y cronologías discutidas diferenciadas.
- Revisión visual de166 candidatos:123 aceptados con pies documentales y43 descartados. Bloqueo de imágenes rechazadas para evitar su recuperación automática.
- Continuidad de selección entre Sámi/Samis, Beothuk/Boethuk y comunidades de Madagascar; originales y decisiones dentro de la entidad correspondiente.
- Capturas de la prueba de Song/sigloXII con45segundos y animaciones desactivadas, conservando todas las comprobaciones; corrección del fallo de publicación0.31.1.
- Auditorías y pendientes documentales explícitos; no se inventan banderas ni retratos contemporáneos.

## 0.31.1 · 28 de octubre de 2026

- Fotografía de Gabriel Terra durante su toma de posesión de1931 en lugar del cartel propagandístico usado en la ficha deUruguay1933. Original, procedencia y corrección dentro de la carpeta deUruguay; fechas y cargos conservados.
- Doble clic derecho con ratón orienta el mapa con el norte arriba enMercator y globo, conservando centro, zoom e inclinación. El arrastre derecho mantiene la rotación y un clic aislado no restablece la vista.
- Correcciones de retratos por entidad reproducibles sin reconstruir mandatos, fronteras o instituciones.

## 0.31.0 · 28 de octubre de 2026

- Continuidad de1.769 contextos culturales desde1906 hasta el presente, con horizonte de consulta2027 y aviso explícito de ausencia de observaciones futuras. El año máximo sigue al reloj del dispositivo.
- Hitos fechados sámi, ainu, maoríes, inuit, métis, mapuches y australianos, distinguiendo institución, pueblo, reserva, residencia y soberanía.
- 1.782 fases nuevas sin nuevos polígonos;6.815 fases anteriores preservadas. Las49 referencias a antiguos poderes políticos no se prolongan automáticamente.
- Auditoría1900–2027, selección política/cultural coincidente, persistencia y consulta móvil. Descargas por siglos; URL previa1900–1905 conservada como archivo.
- Continuación anterior a900, expansión humana y futuras capas científicas de glaciaciones/cambios ambientales registradas como próximos trabajos.

## 0.30.0 · 28 de octubre de 2026

- Ampliación cultural 1700–1905 y revisión conjunta 900–1905: siete instantáneas nuevas, 2.513 pares nombre/instantánea y 6.657 dossiers acumulados por entidad.
- Continuidad de regiones y pueblos bajo la expansión colonial, con consulta de coincidencias y prioridad política. Áreas históricas anteriores identificadas como referencia, sin inventar residencia constante, fronteras anuales o extinciones.
- Contrastes de seminolas, comunidades métis, Aotearoa, Australia/Tasmania, Mapuche, Hawái y África austral; variantes de nombres y componentes insulares separados.
- Once segmentos regionales por siglo, reutilizados al viajar; mismas coordenadas y detalle que el export auditable completo.
- Auditoría de 1.006 selecciones anuales, conservación de originales y revisión explícita de enlaces pendientes con la base política. Las carencias locales siguen abiertas y documentadas.

## 0.29.0 · 27 de octubre de 2026

- Revisión conjunta de pueblos y regiones de 1200–1700 con diez instantáneas de referencia. Continuidad de las fichas entre fases espaciales y conservación de los 127 registros anteriores.
- 4.000 pares nombre/instantánea inventariados, con decisiones canónicas por entidad: incorporación, consulta en la base política o exclusión razonada. Detalle de América, Siberia, África y Oceanía, con coordenadas originales y procedencia.
- Áreas tradicionales de cronología local pendiente identificadas en las fichas; no se presentan como fronteras anuales ciertas. Separación de Hawái/Rapa Nui, fases de Aotearoa y correcciones de anacronismos y traslados modernos.
- Prioridad de las subdivisiones culturales sobre los agregados regionales de fondo; prioridad política conservada. Carpetas canónicas estables aunque cambie el nombre mostrado de una fase.
- Disponibilidad por año, auditoría nominal, conservación e incertidumbres registradas. Revisión posterior a 1700 pendiente.

## 0.28.0 · 27 de octubre de 2026

- Fondo de pueblos/regiones y referencias territoriales 900–1200, activo inicialmente, separado de la cartografía política. Los Estados mantienen colores, geometrías y prioridad de selección. Coincidencias consultables desde la ficha.
- 129 dossiers por entidad, 127 referencias adoptadas y dos exclusiones justificadas. 61 regiones culturales/geográficas y 66 referencias políticas; las referencias políticas ya representadas se suprimen sin mezclar sus fronteras antiguas con las de la base anual.
- Fichas regionales con año del mapa, ventana de consulta, fuentes, incertidumbre y pendientes; sin gobernantes/banderas heredados. Persistencia entre fechas, búsqueda y consulta de entidades superpuestas.
- Contrastes de Amazonia, sociedades misisipianas, Ártico/Dorset/Thule, Hokkaidō, África y otros casos. Correcciones de Merina, Gran Zimbabue, Benevento, Suabia y Hawái; conservación de coordenadas, metadatos y atribución originales.
- Inventario de instantáneas 500/1000/1492 y protección frente a pérdidas al ampliar cobertura. Fuera del periodo revisado se explica la falta de cobertura, sin inferir despoblación o extinción.


## 0.27.0 · 27 de octubre de 2026

- Navegación anual900–999 con531 intervalos originales y77 reglas fechadas. Se conservan las geografías anteriores.
- Dossiers de investigación dentro de cada entidad dePaíses: autoridades, sedes, formas políticas, contextos y decisiones de imágenes.
- Se distinguen Wessex/Inglaterra, realeza germánica/coronación imperial, emirato/califato cordobés, dinastías chinas y sucesiones coreanas. No se inventan límites ni banderas medievales ausentes.
- Fechas ISO con año de cuatro dígitos: las fichas, instituciones y organizaciones no confunden900 con fechas posteriores.
- Selector de fecha reducido a campo y confirmación; sin título grande ni fondo oscurecido, manteniendo teclado, cierre y validación.
- Carencias nominales, fuentes y alcance en [RESEARCH-900.md](docs/RESEARCH-900.md) y [REVIEW-900-999.json](docs/REVIEW-900-999.json).

## 0.26.1 · 27 de octubre de 2026

- Correcciones canónicas en14 carpetas dePaíses, con originales, fuentes y copia de ejecución registrada;44 intervalos de cargos y11 registros institucionales.
- ProvinciasUnidas: tricolor histórico propio, estatúderes con ámbito provincial, regencias y periodos sin estatúder. Río de laPlata: juntas, triunviratos, directores, presidencia provisional y autonomías sin ejecutivo nacional; símbolos continuados hasta1831.
- Luisiana: titularidad francesa diferenciada de la administración española de1802. UniónSuecia/Noruega: ficha de la unión recuperada desde el mapa, pabellón anterior a1844 y reyes comunes sin borrar los dos reinos. Paraguay: ventanas de símbolos y eliminación de una atribución anacrónica al presente.
- Urgell,Empúries,Portugal,UniónIbérica,Georgia,Nóvgorod,Moscú yRiazán: armas, sellos o enseñas con función explícita. Referencias retrospectivas separadas de vigencias históricas; no generan adopciones ficticias en la cronología.
- Conservadas las demás1.109 identidades y49 recursos geográficos byte a byte. La revisión no equivale a completar todos los principados rusos ni a acreditar una bandera nacional uniforme para cada entidad medieval.

## 0.26.0 · 27/10/2026

- Navegación anual hasta1000:713 intervalos originales,62 reglas fechadas y conservación de trece geografías previas.
- 310 intervalos de cargos seleccionados,72 de adquisición regional y142 retratos/efigies adoptados. Se distinguen restauraciones, coronaciones, regencias y dignidades personales;31 imágenes asociadas no adecuadas retiradas de las fichas y diez representaciones rotuladas.
- Sello documental deRobertoII fechado1006–1030; sin retrotraer enseñas posteriores. 38 registros institucionales,46 sedes y18 contextos con diez puntos regionales.
- Corregida la identificación buyí/abasí y la prolongación del califato cordobés por un pretendiente posterior. Carencias y límites en [RESEARCH-1000.md](docs/RESEARCH-1000.md).
- Retirada la i inferior izquierda. Sus créditos y enlaces se integran, plegados, en Datos y fuentes; la escala permanece en su posición.

## 0.25.0 · 27/10/2026

- Navegación anual hasta1100: 541 intervalos originales y65 reglas fechadas; doce geografías anteriores conservadas byte a byte.
- 357 intervalos de cargos seleccionados y67 de adquisición regional. Esteban/Matilde, Portugal, Aragón, títulos imperiales y bohemios, Song, Japón y Goryeo conservan fases y funciones distintas.
- 228 imágenes recuperadas y196 retratos/efigies adoptados tras revisión visual;32 pares rechazados por no identificar al gobernante. Catorce representaciones documentales rotuladas; decisiones persistentes para no reintroducir objetos o personajes distintos.
- Cinco ventanas de símbolos,39 registros institucionales,51 sedes/cortes y18 contextos con nueve puntos regionales. No se retrotraen banderas posteriores ni se inventan límites para resolver defectos de la fuente.
- Claves continuas al cruzar1199–1200; fichas persistentes y aro de carga conservados. Auditoría y pendientes en [RESEARCH-1100.md](docs/RESEARCH-1100.md).

## 0.24.0 · 27/10/2026

- Navegación anual hasta 1200: 862 intervalos originales y 84 reglas fechadas; once geografías anteriores conservadas byte a byte.
- 336 intervalos de cargos seleccionados y 118 de adquisición regional. 237 retratos adicionales adoptados, incluidas dos efigies numismáticas rotuladas; diez monedas sin retrato individual acreditado retiradas de las fichas.
- Diez ventanas de símbolos, 44 registros institucionales, 45 sedes/cortes y 19 contextos con 13 puntos regionales. Coronas castellana y leonesa, poderes bizantinos, regencias mongolas y proclamación Yuan diferenciados.
- Aro animado en el botón de reproducción durante descarga y dibujo del mapa, tanto en reproducción como en saltos manuales. Conserva la ficha durante la espera, sigue la última fecha y se limpia tras errores; compatible con movimiento reducido.
- Comprobación del catálogo por lotes para evitar agotar el tiempo al crecer el número de carpetas, conservando todas las verificaciones. Fuentes y carencias en [RESEARCH-1200.md](docs/RESEARCH-1200.md).

## 0.23.0 · 26/10/2026

- Navegación anual hasta 1300: 774 intervalos adicionales y 70 reglas fechadas; coordenadas originales y cartografía posterior conservadas.
- 241 intervalos de cargos revisados, 154 de adquisición regional y 192 retratos. Reinados interrumpidos, coronas separadas, regencias y cortes rivales diferenciados.
- 11 ventanas de símbolos y tres archivos nuevos: armas francesas antiguas, enseña castellana temprana y águila imperial monocéfala, con límites documentales explícitos.
- 34 registros institucionales, 35 sedes/cortes y 16 contextos con siete puntos regionales de conflictos. Ming y Goryeo disponen de sedes seleccionables cuando falta contorno propio; el agregado Yuan posterior a 1368 no se asigna entero al Yuan del Norte.
- Resolución explícita de alias de artículos para recuperar autoridades verificadas. Auditoría y carencias en [RESEARCH-1300.md](docs/RESEARCH-1300.md).

## 0.22.0 · 26/10/2026

- Navegación anual hasta 1400: 880 intervalos adicionales y 60 reglas fechadas de identidad, con coordenadas originales y cartografía posterior conservadas.
- 206 intervalos de cargos revisados, adquisición regional y 147 retratos adicionales. Reinados interrumpidos, coronas separadas, títulos nobiliarios y poderes rivales diferenciados.
- 13 ventanas de símbolos; enseñas paleóloga y nazarí documentadas, sin retrotraer banderas nacionales posteriores.
- 30 registros institucionales, 33 sedes/cortes y 16 contextos con diez puntos regionales de conflictos. Referencias anacrónicas de fuente identificadas sin importar sus dirigentes al siglo XV.
- Auditoría anual y carencias documentadas en [RESEARCH-1400.md](docs/RESEARCH-1400.md).

## 0.21.0 · 26/10/2026

- Navegación anual hasta 1500: 826 intervalos adicionales y 65 reglas de identidad; coordenadas originales y cartografía posterior conservadas.
- 224 intervalos de cargos revisados, adquisición regional y 192 retratos adicionales. Coronas hispánicas, regencias, pontificados, sucesiones americanas y reinados interrumpidos diferenciados.
- 21 ventanas de símbolos fechados: armas Valois, enseñas castellanas y aragonesas, pabellones portugueses y mon Ashikaga. No se retrotraen banderas nacionales posteriores.
- 39 registros institucionales, 37 sedes/cortes y 17 contextos, con 11 puntos regionales de conflictos. Los agregados cartográficos y las fronteras regionales pendientes quedan señalados.
- Auditoría de los cien años y carencias documentadas en [RESEARCH-1500.md](docs/RESEARCH-1500.md).

## 0.20.0 · 26/10/2026

- Navegación anual hasta 1600: 783 intervalos adicionales, coordenadas intactas y 67 reglas de identidad fechadas; los archivos geográficos anteriores se conservan.
- 196 intervalos de cargos revisados, adquisición regional y 143 retratos. Títulos, regencias, coronas compartidas y autoridades rivales diferenciados.
- 31 ventanas de símbolos documentados. Commonwealth, Portugal y enseñas dinásticas/imperiales fechadas; no se retrotraen banderas posteriores ni diseños ficticios.
- 37 registros institucionales, 30 referencias de sedes y 15 contextos nuevos, con siete puntos regionales de conflictos. Se conserva la separación entre puntos y frentes.
- Fichas coloniales sin extrapolación automática de administradores fuera del intervalo de fuente. Auditoría anual y carencias documentadas en [RESEARCH-1600.md](docs/RESEARCH-1600.md).


## 0.19.0 · 26/10/2026

- Cronología anual hasta1700,853 intervalos adicionales con coordenadas originales y58 reglas de identidad fechadas. Los archivos geográficos anteriores se conservan.
- 275 intervalos de autoridades revisados, ampliación de retratos y39 ventanas de símbolos. Sellos, mon, armas, estandartes y pabellones identificados; no se retrotraen banderas nacionales posteriores ni diseños ficticios.
- Filtros en un nuevo botón de embudo a la izquierda deCapas: forma política/régimen, color del mapa y organizaciones. Opciones sin entidades ocultas; filtro activo vacío conservado con aviso y acción para quitarlo.
- Sedes seleccionables para Estados germanos agrupados en la cartografía, sin inventar sus fronteras.32 referencias urbanas,29 registros institucionales y15 fases documentales adicionales, con puntos regionales de conflictos.
- Auditoría anual1700–1799 y carencias nominales conservadas. Fragmento deSunjo retirado como retrato identificativo porque no conserva un rostro reconocible. [Fuentes, alcance y continuidad](docs/RESEARCH-1700.md).

## 0.18.0 · 26/10/2026

- Revisión de autoridades y símbolos1800–1900; Habsburgo y Río de la Plata dejan de apuntar a identificadores ajenos a la entidad histórica. República Helvética, colonias, títulos soberanos y sucesiones diferenciados.60 retratos y47 ventanas de símbolos revisadas.
- Clasificación institucional fechada, taxonomía jerárquica y filtro persistente enCapas eInstituciones. Evaluación V-Dem/OWID1789–2025 separada y atribuida; no extrapolación al presente.
- 68 referencias urbanas y32 puntos de conflictos, separados de las superficies de ocupación. Selección de puntos corregida; capas de control disponibles también con indicadores económicos y organizaciones.
- Catálogo y auditoría anual con huecos nominales; revisión mundial todavía abierta. Alcance y fuentes en[REVIEW-0.18.md](docs/REVIEW-0.18.md).

## 0.17.0 · 2026-10-26

- Ampliación documental1800–1819; regímenes franceses, regencia británica, autoridades españolas e identidades italianas diferenciadas.
- 49 imágenes raster y3 símbolos SVG nuevos; corregida también la ventana prusiana1820–1839.
- Doce fases documentales, tres enlaces y relaciones de colores de estados clientes sin anexión. Se corrige el intervalo condensado dePitt que abarcaba el gobierno deAddington.
- Fronteras originales conservadas; auditoría nominal y pendientes transversales en tareas.md y docs/DELIVERY-0.17.0.md.

## 0.16.0 · 2026-10-26

- Ampliación documental1820–1839 conservando mandatos posteriores y coordenadas de origen.
- Sucesiones británicas, regencia española, regencias brasileñas y Primer Imperio mexicano. Colores de los regímenes españoles diferenciados.
- Catorce fases de contexto, tres enlaces y referencias locales del Pacífico desde1820. Retratos disponibles con licencia y auditoría nominal de carencias.
- Límites y preparación en docs/DELIVERY-0.16.0.md; continuidad en tareas.md.

## 0.15.0 · 2026-10-26

- Ampliación documental de1840 a1859 y recuperación de cargos monárquicos de1840–1879. Corregida la identidad Joseon/Gojoseon y separadas las autoridadesTaiping de la corteQing.
- Regencias españolas y brasileña, Ejecutivo provisional francés, sucesiones hawaianas y fechas gregorianas del relevo ruso de1855. Contextos y enlaces de navegación con precisión explícita.
- Doce ventanas adicionales de símbolos, sieteSVG acreditados y180 imágenes raster adicionales, incluidos dos retratos deVictoria por etapas.
- Auditorías nominales: nueva franja1840–1859 y reducción de huecos anteriores1860–1879. Las carencias de Estados menores, gobiernos y geometrías agregadas permanecen documentadas.
- Verificación de datos con55 recursos y6.054 medios; pruebas limitadas a un proceso para evitar contención de memoria y disco en los conjuntos geográficos grandes.
- Enlace de contexto mediante la entidad histórica aunque carezca de código estadístico. Crimea distingue la incorporación gradual de los aliados; añadido contexto Taiping. Límites de observación diferenciados del cese del cargo.
- Fuentes y límites: docs/RESEARCH-1840.md; comprobaciones en docs/DELIVERY-0.15.0.md; continuidad en tareas.md.


## 0.14.0 · 2026-10-26

- Corregida la selección de identificadores históricos de texto; no se alteran las costas de origen.
- Autoridades más recientes primero y32 ventanas acreditadas de retratos por etapa, incluidos los casosVietnam2007, India1992 yFrancia1888.
- Control ruso enUcrania desde2022 con observaciones fechadas e incertidumbre visible. La referencia2026 sigue siendo17/12/2025.
- Referencias e identidades delPacífico anteriores a2020 sin duplicar componentes deGuam yNuevaCaledonia.
- Incorporación documental parcial1860–1879: autoridades,225 retratos adquiridos, símbolos, contexto y navegación histórica. Los huecos nominales y el retrato individual pendiente deMariaLevi permanecen explícitos.
- Detalle, límites y comprobaciones: docs/DELIVERY-0.14.0.md y tareas.md.


## 0.13.0 · 25/10/2026

- Ampliación documental1880–1899 con autoridades regionales, símbolos, dependencias, contexto y transiciones. Identidades corregidas entreCliopatria yCShapes, conservando las fuentes originales y las particiones bélicas anteriores.
- Groenlandia seleccionable1886–2019 mediante referencia explícita; fases deHawái y transferencia territorial exacta desde1898, sin restos entre costas de distintas fuentes.
- Retratos notificados deIrak,Tayikistán,Bután,Bangladesh,Vietnam,Francia1900,India yNepal. Retirada de personajes ficticios asociados a cargos reales y filtro de adquisición para impedir su regreso.
- Auditoría nominal, catálogoPaíses y pizarra de pendientes actualizados. Conservadas las carencias regionales, el retrato individual pendiente deMariaLevi y la procedencia pendiente deRijal; no se presentan como tareas completadas.

## 0.12.1 · 25/10/2026

- Sustitución de territorios1940–1944 sobre una malla terrestre compartida: se eliminan piezas alemanas remotas, se protegen países neutrales y se conservan las costas de la base fechada. Una sola geometría política para pintura, fronteras, búsqueda y clic.
- Franjas opcionales calculadas contra el controlador final; clientes y control comunista chino dejan de solaparse con un inventario anterior. Continuidad del cliente eslovaco1939 sin reponerChecoslovaquia ficticia.
- Autoridades con formato uniforme de nombre, cargo y fechas; notas documentales extensas dentro deContexto, manteniendo fuentes e incertidumbre.
- 34 retratos suizos originales recuperados(33GIF y1PNG), permisos individualizados y etiquetas delConsejoFederal/presidencia anual diferenciadas. No se alteran fechas ni otros países.
- Continuidad documental de la entidad eslovaca1940–1944: símbolo, presidente, cambioTuka/ŠtefanTiso y un retrato adicional. La ficha abierta conserva autoridades cuando desaparece su geometría independiente.
- Preparación geográfica y auditoría reproducibles, manifiestos con huellas de insumos y catálogoPaíses sincronizado. Se mantienen los límites de las síntesis anuales y los frentes aún pendientes; no se amplía a1880.

## 0.12.0 · 2026-10-24

- Ampliación documental mundial de1900–1919 mediante adquisición aislada y curaciones regionales, conservando las afirmaciones posteriores. Imperios ruso, Qing, otomano y austrohúngaro, monarquías balcánicas y coreana con claves históricas propias; regencias, autoridades rivales y órganos colectivos diferenciados.
- 76 ventanas adicionales de símbolos1900–1919, otra paraEslovaquia1939 y378 nuevas fotografías acreditadas; imágenes locales con autoría, licencia y huella. El pabellón mercante austrohúngaro se identifica como tal, sin inventar una bandera nacional común.
- Correcciones de estatus para Corea1905–1909, antiguas repúblicas bóeres desde1902, Estado Libre del Congo antes de1908 y Marruecos antes del protectorado. Tonga protegido se incorpora como contorno contemporáneo de referencia; sin alterar la topología original ni inventar frentes diarios.
- Tres agrupaciones y48 fases contextuales nuevas, instituciones y sucesiones fechadas. Firma, vigencia, proclamación, reconocimiento y límites de revisión se distinguen. La Triple Alianza no convierte automáticamente a Italia neutral en potencia beligerante en1914.
- Catálogo Países, manifiestos, documentación, auditoría anual y expectativas antiguas de cobertura sincronizados. Se conservan las carencias nominales; disponibilidad de alguna autoridad no equivale a censo exhaustivo mundial de cargos o fronteras.
- Corrección adicional solicitada deAlemania1938–1939: componentes remotos descartados por ámbito territorial, fronteras de vecinos protegidas y territorio alemán disuelto en una entidad seleccionable. Praga1938 sigue checoslovaca; en1939 se separan tierras checas ocupadas, Estado eslovaco cliente y extensión húngara. El apoyo eslovaco es una referencia recortada explícita, con autoridades y bandera propias; no una frontera exacta de1939 ni una corrección mundial de1940–1944.

## 0.11.1 · 2026-10-24

- Corregidas tres expectativas de navegador que quedaron desactualizadas tras ampliar la documentación a1920: organizaciones disponibles en1947, administración aliada colectiva de1946 y varios titulares durante1939.
- Las pruebas verifican ahora ONU/OTAN con su ámbito temporal, desactivación antes de1920, órgano de ocupación sin bandera nacional ni retrato personal inventados, y presencia de Franco/Azaña con el fin del mandato republicano. No se eliminan datos ni se omiten recorridos para superar Quality.
- Ayuda de la capa de organizaciones corregida de1960 a1920. Conservadas las guardas de renderizado, datos, fronteras y configuración de publicación; subida sin espera del despliegue.
## 0.11.0 · 2026-10-24

- Ampliación mundial de autoridades a1920–1949 con adquisición incremental, retratos acreditados y curaciones documentales de sucesiones, monarquías, gobiernos en el exilio y administraciones de ocupación. Rusia soviética, República de China, monarquía yugoslava, Danzig, Tíbet y República Social Italiana tienen identidades propias; no heredan estadísticas de sucesores.
- Símbolos históricos fechados y administraciones dependientes desde1920, distinguiendo colonias/departamentos franceses y Austria bajo control alemán. Se conservan los intervalos posteriores y la referencia contemporánea22/10/2026; las ventanas de revisión no se presentan como nombramientos o dimisiones exactas.
- Sociedad de Naciones y ONU con membresías/representaciones históricas; acceso gradual, retirada, sustitución de entidades y entrada en vigor separados de la firma. Contexto y navegación institucional ampliados; no se inventan frentes militares a partir de textos.
- Corrección documental de Danzig1938: el polígono original se mantiene y se excluye del control alemán un año antes de la anexión real. La topología incorporada no se modifica. Vaticano sólo aparece desde la entrada en vigor de los acuerdos de1929.
- Resaltado de selección mediante estado de pintura, evitando reanalizar las teselas al mismo tiempo que cambian las fronteras. Conserva la actualización incremental y las guardas; corrige el atasco reproducido al mantener Rusia abierta entre1920y1921.
- Catálogo Países y manifiestos sincronizados; fecha visible de Acerca de corregida. Auditoría nominal por décadas, carencias y límites de la ampliación registrados para continuidad.
- Comprobación local y subida sin esperar ni sondear el despliegue, por instrucción del propietario. Validación pública pendiente de su aviso.

## 0.10.0 · 2026-10-24

- Ampliación incremental de autoridades y medios a1950–1959; correcciones focales de cargos formales/efectivos, monarquías y órganos colectivos. Estado de Vietnam y Federación de Malaya separados de sus sucesores; sin estadísticas actuales retrotraídas.
- Banderas históricas, fotografías acreditadas, administraciones dependientes desde1950, contexto y conflictos de la década. Organizaciones fechadas: CECA, Euratom, ANZUS, SEATO y Bagdad/CENTO; Cuba/OEA corregida a1962. Los huecos y límites quedan inventariados.
- Carpeta Países con índice y un resumen por entidad incorporada; medios y geometrías originales conservados sin copias redundantes. Recursos locales de audio/PDF declarados por entidad y vigencia se detectan al compilar y aparecen en Datos; no se incorporan grabaciones por defecto.
- Cabecera, bandera y pestañas fijas en la ficha; desplazamiento interior sin barra visible. Acciones de comparación dentro de Comparar. El símbolo enlaza a su procedencia sin el desplegable «Fuente de la bandera».
- Por instrucción del propietario, las entregas se comprueban localmente y se suben sin esperar ni consultar el despliegue remoto. La revisión pública queda pendiente de su aviso.

## 0.9.1 · 2026-10-23

- Cinco retratos de India añadidos con GODL-India: el filtro reconoce la marca ND sin confundirla con parte del nombre de esa licencia. Auditoría final:91 personas/órganos sin imagen y3.793 medios.
- Publicación protegida frente a comprobaciones de revisiones superadas; concurrencia de Quality por rama y Pages vinculado al commit vigente verificado.

- Los preparadores conservan los retratos antes de regenerar mandatos curados. Recuperados26 retratos ya presentes y acreditados en el inventario de medios; se conservan sus referencias sin añadir archivos redundantes por esa recuperación.
- Presidencia parlamentaria de Azikiwe y Gobierno de Balewa diferenciados; se elimina una atribución genérica duplicada. Catálogo de7.480 mandatos.
- La consolidación de autoridades no recupera cargos descartados por una corrección revisada. Adquisición focal admite el original publicado con límite de5MB, conservando filtros de identidad, licencia y exclusiones.
- Inventario durable de investigación pendiente y cierre de comprobaciones/publicación separados de la implementación.

## 0.9.0 · 2026-10-23

- Control territorial integrado en la geometría seleccionable; el interruptor de ocupaciones activa franjas, apagadas inicialmente, con color fino del territorio ocupado y grueso del controlador. Incorporación y ocupación diferenciadas dentro de la cobertura documental.
- Fondo terrestre de referencia en todo el dominio histórico para evitar huecos políticos del color del océano; no implica territorios deshabitados ni costas históricas reconstruidas.
- Familias cromáticas históricas, matices de dependencia, contraste británico/soviético y cambios de régimen. Paleta editorial exportada en CSV, separada de ideologías modernas.
- Ampliación de autoridades, símbolos y contexto a 1960–1969, con entidades históricas propias, República Árabe Unida, Tanganica/Zanzíbar, Yemen monárquico y administradores UNTEA. Ventanas de cobertura y mandatos exactos conservan su distinción.
- Membresías desde 1960, nuevas relaciones navegables e instituciones focales. Auditoría durable por país-año y pizarra `tareas.md`; fotos, símbolos, frentes y suplencias pendientes expresos.
- El CSV adjunto del propietario no estaba disponible en la ruta indicada: no se declara importado. Investigación, validación y estado de entrega en DELIVERY-0.9.0.

## 0.8.1 · 2026-10-23

- Corregida la pérdida de nombres, identidades y colores tras actualizaciones de año: las diferencias de propiedades usan borrados explícitos compatibles con el índice de teselas. Los clics consultan el registro completo del territorio activo.
- Autoridades locales y del Estado administrador diferenciadas en dependencias. Once relaciones documentadas y resolución general del administrador de la fuente, con límites temporales y sin heredar estadísticas nacionales.
- Angola, Mozambique, Guinea-Bisáu, Namibia, Sáhara español, Surinam, Bahamas, Puerto Rico y departamentos franceses dejan de ocultar sus autoridades estatales. Gobiernos autónomos y fechas de independencia conservan su ámbito; Namibia no se presenta como soberanía sudafricana reconocida.
- Cinco mandatos focales añadidos y dos retratos con licencia, conservando todo el catálogo anterior. Regresiones sobre el motor de teselas y clics reales tras viajar fuera del periodo revisado y volver.

## 0.8.0 · 2026-10-23

- Ampliación mundial de mandatos fechados y retratos hasta 1970, conservando la adquisición anterior. Curaciones de cargos históricos, juntas, autoridades de facto y sucesiones breves; Vietnam del Norte, República de Vietnam, Gobierno Revolucionario Provisional y Rodesia separados de sucesores.
- Correcciones de identidad territorial y datos estadísticos para Vietnam, los dos Yemen y Rodesia; capital Salisbury en su periodo. Bangladesh y descolonización con fechas de fuente. Suplementos insulares desde sus fechas documentadas; Sáhara español y posterior territorio no autónomo diferenciados, con contornos marroquí/mauritano de referencia de 1974 identificados.
- 31 organizaciones y 546 intervalos de participación desde 1970: OCDE, UMA y dos instituciones EAC históricas añadidas, adhesiones y rupturas previas completadas, límites de cobertura explícitos y aplicaciones territoriales distintas de Estados miembros.
- 205 fases de conflictos/transiciones, 50 relaciones entre entidades y 49 registros institucionales/históricos. Separadas fases que anticipaban hechos posteriores; los registros abiertos no se extrapolan más allá de la referencia.
- Familias de color para dependencias y tutelas: matices rojos soviéticos, clientes y administradores documentados. Modelo general fechado y fuentes en la ficha; la pertenencia a una alianza no implica dominación. Intervenciones/ocupaciones respetan el control de capa.
- Se conservan las doce pestañas, fichas abiertas al cambiar de año, cronologías, comparación y gráficos. La referencia contemporánea no avanza por adquirir documentos del pasado.
- Banderas y fotografías mantienen licencias y atribuciones individuales. Persisten imágenes sin fuente reutilizable, cargos secundarios y frentes/regímenes regionales pendientes de contraste; la auditoría anual no equivale a revisión historiográfica mundial exhaustiva.

## 0.7.0 · 2026-10-23

- Fichas persistentes durante cambios de año, reproducción y cargas: entidad, pestaña y posición de lectura conservadas. Las entidades desaparecidas permanecen abiertas con ausencia explícita y navegación a entidades relacionadas. Capitales enlazadas entre fuentes por identidad y nombre normalizado.
- Doce apartados: autoridades, territorio, instituciones, sociedad, economía, relaciones, defensa, historia, datos, contexto, conflictos y comparación. Búsqueda, fuentes y capas se mantienen al recorrer fechas.
- Comparación de dos fechas y de hasta cuatro entidades fijadas, con mandatos, símbolos, cifras fechadas, diferencias y alternancia del mapa. Gráficos con tablas accesibles, magnitudes con signo y huecos sin interpolar.
- Cronología filtrable y navegable a partir de mandatos, símbolos, organizaciones y acontecimientos; futuros respecto al año consultado sólo bajo opción explícita.
- 22 indicadores WDI adicionales, 175.996 observaciones de 217 economías (1960–2025), licencias individuales comprobadas. Personal militar con cobertura hasta 2020; gasto SIPRI no redistribuido.
- 33 relaciones entre entidades y 28 registros institucionales/históricos/territoriales con 36 fuentes oficiales. Modelo ampliable con campos fechados y lugares por apartado; no es cobertura constitucional mundial completa.

## 0.6.0 · 2026-10-23

- Ampliación mundial de mandatos, retratos y banderas de 1990–2026; cargos nacionales e identidades de Yugoslavia, R. F. de Yugoslavia, Serbia y Montenegro, Checoslovaquia y Yemen anterior. Curaciones previas conservadas y límites de cese inciertos identificados.
- Sáhara Occidental: explicación de territorio no autónomo, autoridades saharauis y marroquíes con ámbitos distintos, sin convertir el símbolo de la RASD en un reconocimiento de soberanía resuelta.
- 27 organizaciones con 474 intervalos de membresía, altas/bajas y categorías: ampliaciones OTAN/CE-UE, Brexit, acuerdos comerciales y agrupaciones africanas, americanas, asiáticas y de Oriente Medio. No se retroproyecta una lista actual; las suspensiones históricas focales conservan su límite de cobertura.
- Contextos y conflictos por fases desde 1990, con fuentes por registro y sin inferir beligerancia de una alianza. Hechos del año en Contexto y fechas de relación en Datos.
- Crimea vuelve a la base territorial ucraniana de referencia anterior a 2014; la ocupación permanece separada. Estados pequeños omitidos por CShapes se incorporan con contornos contemporáneos identificados, y el Sáhara se distingue de Marruecos. Sin líneas militares inventadas.
- Buscador compacto, sin diálogo modal ni oscurecimiento, con teclado y nombres alternativos. Tema de tarde en cobre/ámbar, conservando océano más claro que fondo.
- Conservadas las renovaciones consecutivas de un dirigente en la misma fecha de relevo; las jefaturas de Estado y Gobierno coincidentes se identifican conjuntamente.

## 0.5.0 · 2026-10-22

- Corregida la identidad española que se aplicaba a otros países al comparar identificadores vacíos. Corregida también la sobrescritura de Brasil, Francia, Australia y Kazajistán por metadatos de territorios asociados.
- Ficha de país a la izquierda, con pestañas Autoridades, Datos, Contexto y Conflictos. Se listan los mandatos que coinciden con el año, incluidos relevos breves y jefaturas de Estado/Gobierno.
- Fotografía oficial completa de la primera ministra de Mozambique, con atribución y licencia no comercial/sin derivados, conservando el encuadre original.
- Ampliación mundial de fotografías locales y contraste de autoridades de 2026 con ONU y fuentes nacionales; cobertura y excepciones auditadas en CURRENT-AUTHORITIES.
- Mañana, tarde, noche y automático en un botón cíclico; hora local del dispositivo, preferencia conservada y océanos más claros que el fondo.
- Relieve apagado de inicio y disponible como referencia en periodos históricos desde 10.000 a. C.; excluido de reconstrucciones geológicas.
- Eliminado Explorar épocas y el rótulo de escala adaptativa. Leyenda a la derecha, atribución/escala a la izquierda y fuentes en un panel compacto sin fondo modal.
- Capas 2026 de OTAN, UE, BRICS y Tres Mares; categorías separadas y fuentes oficiales. Rampa económica verde y contextos parciales de conflictos con fuentes.
- Pruebas de regresión con clic cartográfico en Brasil 1947 después de consultar un bando español, claves de territorios, pestañas, temas y alcance temporal de membresías.

## 0.4.0 · 2026-10-22

- Cronología anual ampliada a 1789: componentes Cliopatria 1789–1885 y todos los registros CShapes desde 1886, sin retrotraer un mapa futuro por cercanía. Inventario de 238 selecciones hasta 2026.
- Control territorial opaco por potencia, con Alemania nazi gris, URSS roja, Estados Unidos azul y familias políticas diferenciadas. Colores de regímenes franceses y españoles; dependencias, aliados, ocupación y gobiernos clientes separados.
- Extensiones de ambas guerras mundiales, regímenes de Croacia y Vichy y control comunista chino. Hungría aliada no se equipara a Hungría ocupada en 1944.
- Guerra Civil española: dos bandos en 1936/1937/1938 y resultado de 1939. Frente de octubre de 1937 georreferenciado con fuentes, atribución e incertidumbre; sin interpolación de provincias.
- Fichas integradas con bandera histórica, nombre, autoridades y retratos reales con licencia. Series focales de EEUU, España, Alemania, URSS y Francia, y catálogo global de mandatos con cobertura desigual. No se asignan dirigentes actuales a periodos sin documentación ni banderas de RFA/RDA a la ocupación anterior a 1949.
- Búsqueda de bandos y áreas controladas, fichas comunes a búsqueda/clic y tratamiento de mandatos repetidos. Metadatos e imágenes locales, sin llamadas a Wikidata/Commons al navegar.
- Fuentes y fichas extraídas a módulos propios; pruebas geográficas, de identidades, de periodos, integridad de medios y navegador. Límites y continuación documentados.

## 0.3.0 · 2026-10-22

- Selección por intervalos de vigencia para 1900–2019, con CShapes 2.0: colonias, protectorados, mandatos, administradores y capitales históricas. 1942 deja de seleccionar el mapa de 1945.
- Capa anual de extensión territorial de Alemania, Japón e Italia en 1938–1944, a partir de Cliopatria; sin atribuirle una fecha diaria uniforme.
- Polígonos contextuales de Sinaí, Golán y Crimea que distinguen ocupación y soberanía; límites y fases pendientes explicados.
- Reproducción reciente anual que espera la carga, comparte descargas y conserva el mapa anterior mientras carga. Pausa invalida la continuación pendiente.
- Año máximo obtenido del dispositivo; referencia contemporánea desde 2020 identificada como tal, sin inventar verificación anual o conocimiento futuro.
- Fichas ampliadas: capital, estatus, administración, contexto y seis indicadores WDI con su fecha. Sin cifras actuales proyectadas retrospectivamente.
- Capas de PIB total, PIB por habitante y población con leyenda y años observados.
- 323 capitales y grandes ciudades actuales, y capitales históricas por periodo.
- Informe anual de cobertura, cambios y pendientes, con pruebas históricas y de reproducción.

## 0.2.0 · 2026-10-22

Rediseño del espacio de exploración y de los controles.

- Eliminadas la cabecera permanente, las franjas superior e inferior de la regla y los controles laterales de zoom/restablecimiento.
- Herramientas compactas en la esquina superior derecha: búsqueda, cambio 2D/3D con un único botón, capas, base de datos/fuentes, pantalla completa e información.
- Capas en un panel desplegable con cierre por Escape o al pulsar fuera.
- Fecha seleccionada y reproducción/saltos reunidos en el centro fijo de la regla.
- Rueda sobre la regla para ampliar/reducir su escala sin cambiar la fecha; la rueda sobre el mapa conserva su zoom geográfico.
- Marcas temporales adaptadas al zoom y a la ventana visible, con navegación por arrastre y teclado.
- «Acerca de» con favicon, identidad, ficha de versión, historial, portfolio confirmado y repositorio, siguiendo la estructura de los proyectos del autor.

## 0.1.0 · 2026-10-21

Primera base funcional del atlas temporal.

- Mapa Mercator y globo con cartografía vectorial, selección, zoom y búsqueda.
- Regla móvil con cursor fijo, escala adaptativa, fechas, épocas y reproducción.
- 26 instantáneas con procedencia, licencias y verificación SHA-256.
- Contexto, fuentes, metodología, versión e historial.
- Relieve actual y tres lugares introductorios.
- Diseño adaptable, navegación por teclado y enlaces compartibles.
- Documentación de continuidad y flujos de validación/publicación.
- Teselación subpíxel para evitar exceder límites GPU en costas densas; comprobación de renderizado de todas las instantáneas.
- Movimiento de regla con marcas reutilizadas y sincronización limitada del enlace compartible para mantenerlo correcto durante la reproducción.

Cobertura inicial discontinua. Alta resolución local, revisión historiográfica exhaustiva, homininos, hielo, atmósfera y eventos bélicos pendientes. Ver `agentes.md`.


Corrección de publicación25/10/2026: Quality40208104708 pasó para33637c5; Publish40209978935 se omitió porque el cierre documental3f2c2f5 adelantómain y la condición comparaba ambosSHA. Se elimina esa igualdad y se conserva checkout delSHA validado, con éxito/push/main/mismo repositorio. Reejecutar un workflow_run conserva su evento antiguo; usar una ejecución manual nueva. No se cambian datos ni aplicación. No esperar despliegue.

