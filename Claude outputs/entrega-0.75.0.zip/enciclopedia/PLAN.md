# Enciclopedia de Historicmap · Plan de proyecto

> El estado actualizado de todas las fases y el plan detallado de lo que queda están en [`../PLAN.md`](../PLAN.md).

Documento rector de la reconstrucción completa de «la enciclopedia». Redactado en la fase **P00** (7 de noviembre de 2026, sobre la versión 0.56.0, commit `8004e266f`). Cada fase se ejecuta solo cuando el propietario la ordena («empieza la P0X»). Al cerrar cada fase se actualizan este plan, `tareas.md`, `agentes.md` y `CHANGELOG.md`, y se entregan los comandos de Git para que el propietario suba el resultado.

---

## 1. Diagnóstico de partida (P00)

### Lo que existe hoy

| Pieza | Estado |
|---|---|
| Lector | `src/encyclopedia.ts` (13 KB), `encyclopedia-model.ts`, `human-encyclopedia.ts`, `encyclopedia-diagrams.ts`, `encyclopedia.css`. Diálogo a pantalla completa, búsqueda local, historial, «Ver en el mapa», carga diferida (chunk de 167 KB). |
| Contenido | 291 entradas: 91 artículos (21 Precámbrico, 20 Fanerozoico, 1 Cuaternario, 49 de humanidad), 177 unidades geológicas ICS y 23 edades humanas. En total unos **77 KB de texto** de artículos geológicos: el artículo «Jurásico» tiene 4 párrafos y no menciona sus tres series ni sus once edades. |
| Unidades geológicas | Las 177 unidades (4 eones, 10 eras, 22 periodos, 37 épocas, 101 edades) solo muestran una plantilla genérica («X se consulta para…») sin contenido propio. |
| Historia | **Nada**. No existe ninguna página de contexto mundial, entidad política, dirigente, guerra, pandemia ni monumento. |
| Datos aprovechables | 5.290 expedientes en `Países/` (3.995 entidades políticas, 503 culturas, 792 yacimientos) y **12.606 dirigentes distintos**, el 97 % con identificador Wikidata (QID). Distribución: 10 antes de 2500 a.C., ~1.400 en la Antigüedad, ~2.600 entre 500 y 1500, ~6.000 entre 1500 y 2000. |
| Estilo | Texto burocrático y defensivo («no certifica», «no equivale a», «referencia editorial»). Los avisos metodológicos se comen el contenido. |

### Hallazgos colaterales

- **Clon roto en Windows**: 21 rutas de `Países/` superan los 260 caracteres de Windows (la más larga mide 244 + `D:\Proyectos\Historicmap\`). La descarga fue completa, pero el checkout se abortó y el índice de Git quedó vacío; por eso `git status` muestra los 40.404 archivos como «borrados». Solución en el apartado 6.
- **Carpeta duplicada**: `EGYPT-HERACLEOPOLITAN-POWERS-…-nort` y `…-norte` coexisten (la primera es un nombre truncado). Pendiente de revisar con los datos de países; no se toca en la enciclopedia.
- **Idiomas**: la aplicación solo está en español. La arquitectura nueva admite traducciones por archivo, pero traducir una enciclopedia de este tamaño a 7–12 idiomas es una decisión aparte (fase opcional P-X2).
- **Despliegue**: la compilación pura (`vite build`) tarda unos 3 s; lo lento es la batería de navegador (8 grupos + barrido anual). La enciclopedia nueva solo añadirá **pruebas unitarias rápidas** (Vitest) y como mucho un recorrido de navegador, para no alargar Actions.

---

## 2. Visión

Historicmap tiene dos caras: la **sencilla** (moverse en el tiempo, pulsar un país y ver quién mandaba) y la **técnica**, que es la enciclopedia. La enciclopedia debe ser:

1. **Monumental y rigurosa**: cantidad sin perder calidad, sin repetir contenido entre páginas (se enlaza en vez de repetir).
2. **Autocompositiva**: una unidad superior se lee como un documento que **incluye a sus hijas**. «Jurásico» = introducción propia + Jurásico Inferior (Hettangiense, Sinemuriense, Pliensbachiense, Toarciense) + Medio + Superior (Oxfordiense… Titoniense). «Titoniense» se lee solo. Lo mismo para eras, eones, imperios con sus dinastías, guerras con sus batallas.
3. **Contextual por fecha**: al abrirla desde el mapa en el año X se muestra **«El mundo en X»**: panorama global y por regiones (continentes, culturas, imperios), unidad geológica vigente, eventos del año y dirigentes activos. La granularidad se adapta: miles de millones de años en el Hádico, milenios en el Paleolítico, siglos/décadas en la Antigüedad, años en la Edad Contemporánea.
4. **Hipervinculada**: todo nombre propio relevante enlaza (personas, entidades, eventos, eras, especies, conceptos). Enlaces que viajan por el tiempo; historial adelante/atrás.
5. **Visual**: gráficos (temperatura, CO₂, O₂, nivel del mar, biodiversidad, población), líneas de tiempo interactivas, esquemas SVG propios, tablas comparativas, fotografías y reconstrucciones con licencia y crédito.
6. **Conectada al mapa**: la regla cronológica (nombres de eras clicables), las fichas de país (icono «consultar» junto a cada dirigente), las manchas de homininos y culturas, y los yacimientos abren su página.
7. **Escrita con voz enciclopédica**: clara y técnica; la incertidumbre se explica una vez, donde importa (apartado «Evidencias y debate»), no en cada frase.

---

## 3. Arquitectura propuesta

### Carpeta raíz `enciclopedia/`

```text
enciclopedia/
  PLAN.md                 este documento
  README.md               guía editorial y de formato (P01)
  esquema/                tipos de página, campos obligatorios, validador
  geologia/               eones, eras, periodos, épocas y edades (177 unidades ICS + informales)
  tierra/                 formación, atmósfera, océanos, tectónica, supercontinentes, impactos
  clima/                  glaciaciones (todas), invernaderos, eventos hipertermales
  vida/                   origen y evolución de la vida, extinciones, bestiario (dinosaurios, megafauna…)
  humanidad/              homininos, migraciones, yacimientos clave, tecnologías prehistóricas
  culturas/               culturas y comunidades prehistóricas y protohistóricas (las 503 de Países/)
  contextos/              «El mundo en…»: panoramas por intervalo, con desglose regional
  entidades/              imperios, reinos, repúblicas, estados (vinculados a las claves de Países/)
  personas/               biografías, nombradas por QID de Wikidata (Q1407-tiberio.md)
  eventos/                guerras, batallas, revoluciones, pandemias, tratados, hitos (Luna 1969…)
  obras/                  monumentos y grandes obras (pirámides, Gran Muralla…)
  temas/                  conceptos transversales (religiones, escritura, imprenta, metalurgia…)
  medios/                 imágenes con ficha de licencia, autor y fuente
  _generado/              índice, búsqueda y relaciones compilados (no se edita a mano)
```

### Formato de una página

Markdown con cabecera YAML, para poder escribir textos largos con comodidad:

```markdown
---
id: persona/Q1407
tipo: persona
titulo: Tiberio
alias: [Tiberio Julio César Augusto]
fechas: { inicio: -42-11-16, fin: 37-03-16 }
anclaMapa: 33            # año que abre «Ver en el mapa»
entidades: [ROMAN-EMPIRE-CLASSICAL]
padre: null              # o la unidad/entidad que lo contiene (composición)
relacionados: [persona/Q1405, entidad/ROMAN-EMPIRE-CLASSICAL]
fuentes: [wp-es-tiberio, suetonio-vidas]
infobox: { ... }         # datos de la ficha lateral
---
## Infancia y familia
Texto con enlaces internos: [[persona/Q1405|Augusto]], [[evento/batalla-teutoburgo]].
```

- Un compilador (`scripts/build-encyclopedia.mjs`, Node puro, sin dependencias nuevas) valida las páginas, resuelve enlaces, detecta enlaces rotos y genera `_generado/` (índice, búsqueda, árbol de composición, índice temporal). Se ejecuta antes de `vite build` y tarda segundos.
- Cada página se carga **bajo demanda** (fragmento propio). El peso del programa principal no crece aunque la enciclopedia ocupe decenas de MB.
- Lo ya existente en `Tierra/` (ICS, curvas PhanDA, CO₂, LR04, linajes, fotos) se **reutiliza por referencia**, sin duplicar datos científicos.
- Los dirigentes de `Países/` se enlazan por QID: si existe `personas/Q….md` se abre la biografía; si no, una **ficha mínima generada** con lo que ya sabemos (cargos, fechas, entidad, retrato) y la marca «biografía en preparación».

### Niveles de profundidad

| Nivel | Qué es | Volumen orientativo |
|---|---|---|
| **A · Monografía** | Página extensa escrita a mano, con gráficos, imágenes y esquemas | 600–900 páginas |
| **B · Artículo** | Página completa pero más breve (3–8 apartados) | 2.500–4.000 páginas |
| **C · Ficha generada** | Datos estructurados + resumen breve, a partir de Wikidata/Wikipedia y los propios datos | el resto de los 12.606 dirigentes y entidades |

### Fuentes, licencias y estilo

- Wikipedia (es/en) como base principal, contrastada con fuentes especializadas (ICS, USGS, NASA, Smithsonian, Britannica, artículos científicos). Los textos se **redactan de nuevo**, no se copian; se citan las fuentes en cada página.
- Imágenes solo de Wikimedia Commons u otras fuentes con licencia libre verificada, con autor, licencia y URL registrados (como ya se hace con los retratos).
- Sin repetir: una idea vive en una sola página; las demás enlazan.

---

## 4. Fases

Cada fase indica objetivo, entregables y criterio de cierre. Las fases de contenido incluyen siempre: texto, enlaces internos, gráficos/esquemas, imágenes cuando existan, fuentes y pruebas del compilador.

### Bloque 0 · Cimientos

**P00 · Análisis, diagnóstico y plan** ✅
Descarga y diagnóstico del clon, lectura de `agentes.md`, `tareas.md`, código y datos, prueba de compilación, capturas de la enciclopedia actual y este plan.

**P01 · Arquitectura y lector nuevo** ✅ *(0.57.0)*
Carpeta `enciclopedia/` con esquema y guía editorial; compilador con validación y detección de enlaces rotos; lector nuevo: índice lateral por ramas (Tierra, Vida, Humanidad, Historia, Personas, Eventos), ficha lateral (infobox), tabla de contenidos, **composición jerárquica** con secciones plegables (“leer completo” incluye a las hijas), historial, búsqueda con acentos y alias, apertura por fecha. Migración de lo aprovechable de los 91 artículos actuales (quitando la retórica defensiva). Pruebas unitarias rápidas. Instrucciones para ejecutar en local.
*Cierre:* el lector nuevo abre las páginas migradas, compone una unidad con sus hijas y no aumenta el tiempo de Actions de forma apreciable.

**P02 · Componentes visuales e integración con el mapa** ✅ *(0.58.0)*
Biblioteca de componentes: gráficos de series (temperatura, CO₂, O₂, nivel del mar, biodiversidad, población), línea de tiempo interactiva, mapa en miniatura de localización, esquemas SVG reutilizables, tablas comparativas, galerías con créditos, árboles genealógicos y de sucesión. Puntos de entrada: nombres de la regla cronológica, icono «consultar en la enciclopedia» junto a cada dirigente y entidad en las fichas, manchas de homininos, culturas y yacimientos. Canal de medios de Commons con licencias.
*Cierre:* desde cualquier dirigente, era o cultura del mapa se llega a su página (real o ficha generada).

### Bloque 1 · La Tierra antes de la vida compleja

**P03 · Formación de la Tierra, Hádico y Arcaico** ✅ *(0.59.0)*
Nebulosa solar, acreción, Theia y la Luna, océano de magma, primeras aguas y circones de Jack Hills, Bombardeo Intenso Tardío, Eoarcaico→Neoarcaico, cratones, primeras evidencias de vida (LUCA, estromatolitos), atmósfera reductora, día de pocas horas.
*Volumen:* ~35 páginas (A/B).

**P04 · Proterozoico**
Paleo-, Meso- y Neoproterozoico con todos sus periodos (Sideriano → Ediacárico); Gran Oxigenación; formaciones de hierro bandeado y océanos ferruginosos/«rojos»; glaciación Huroniana; «mil millones aburridos»; eucariotas; Columbia y Rodinia; Tierra bola de nieve (Esturtiana, Marinoana, Gaskiers); biota de Ediacara.
*Volumen:* ~35 páginas.

### Bloque 2 · Fanerozoico, unidad por unidad

**P05 · Paleozoico**: Cámbrico → Pérmico con todas sus épocas y edades (~50 unidades ICS): explosión cámbrica, Burgess y Chengjiang, GOBE, extinción Ordovícico-Silúrico, conquista de la tierra, peces y tetrápodos, Devónico tardío, bosques y oxígeno del Carbonífero (artrópodos gigantes), Pangea, glaciación karoo, **la Gran Mortandad** (Trampas Siberianas, hipótesis).
*Volumen:* ~70 páginas.

**P06 · Mesozoico**: Triásico, Jurásico y Cretácico con sus series y 30 edades: origen y radiación de los dinosaurios, extinción Triásico-Jurásico, ruptura de Pangea, aves, plantas con flor, reptiles marinos, **impacto de Chicxulub y extinción K-Pg** (y Trampas del Decán).
*Volumen:* ~55 páginas.

**P07 · Cenozoico**: Paleógeno, Neógeno y Cuaternario con todas sus épocas y edades (Tortoniense incluido): radiación de mamíferos, PETM, glaciación antártica, crisis del Mesiniense e inundación zancliense, cierre de Panamá, megalodón, ciclos glaciales, megafauna y su extinción, Holoceno y sus tres edades, debate del Antropoceno.
*Volumen:* ~55 páginas.

**P08 · Grandes procesos transversales del tiempo profundo**
Páginas resumen con listados enlazados: **las extinciones masivas** (las cinco grandes y las menores), **todas las glaciaciones** (de Pongola a la última; cuántas hay según el criterio), supercontinentes (Vaalbará → Pangea → Pangea Última), grandes impactos, historia del oxígeno y del CO₂, color y química de los océanos, evolución del día y de la Luna. Más el **bestiario**: ~80 fichas de animales y plantas emblemáticas en su época (Tyrannosaurus, Triceratops, Giganotosaurus, Megalodon, Anomalocaris, Meganeura, Dimetrodon, mamut…).
*Volumen:* ~110 páginas.

### Bloque 3 · Humanidad prehistórica

**P09 · Evolución humana**
Ampliación profunda de los 39 linajes (Sahelanthropus → Homo sapiens, pasando por Lucy, *H. heidelbergensis*, neandertales, denisovanos, *floresiensis*, *luzonensis*, *naledi*…), procesos (bipedismo, fuego, lenguaje, cerebro), migraciones fuera de África, yacimientos clave (Atapuerca, Olduvai, Denisova…), tecnologías líticas (Olduvayense → Magdaleniense), mezcla genética. Árbol evolutivo interactivo.
*Volumen:* ~80 páginas.

*Plan detallado de P09 (21/11/2026).* Carpeta `enciclopedia/humanidad/` con cuatro subcarpetas que el índice muestra como subgrupos de la rama «Humanidad». Los 39 linajes y 9 de los 10 temas heredados se sustituyen con su mismo id (`hominin-…`, sin `reemplaza`) y conservan al final sus esquemas y el comparador; las páginas nuevas usan `humanidad-…`. «Del poblamiento a las primeras sociedades productoras» (`neolithic-transition`) queda para P10.

- **P09-0 · Infraestructura (código propio).** Árbol evolutivo interactivo `:::componente arbol-homininos` (eje temporal 7 Ma–hoy, barras con el rango de cada linaje leído de `Tierra/Humanidad/linajes/*/linaje.json`, agrupadas por género, flechas de flujo génico neandertal–sapiens–denisovano, filtro «especies de referencia / propuestas discutidas», clic para abrir la ficha; textos en i18n). Subgrupos de la rama Humanidad por subcarpeta. Pruebas e2e.
- **P09-A · Linajes (39 páginas, `humanidad/linajes/`).** Las especies de referencia, con un mínimo de 2.000 palabras y de 3.000 para las cinco grandes; las propuestas discutidas, con un mínimo de 1.500.
  - A1 · Primeros homininos (6): *Sahelanthropus*, *Orrorin*, *Ar. kadabba*, *Ar. ramidus*, *Au. anamensis*, *Au. afarensis*.
  - A2 · Diversidad australopitecina (8): *bahrelghazali*, *deyiremeda*, *Kenyanthropus platyops*, *Au. africanus*, *prometheus*, *garhi*, *sediba*, Ledi-Geraru *Australopithecus*.
  - A3 · Parántropos y *Homo* temprano (10): *P. aethiopicus*, *boisei* y *robustus*; Ledi-Geraru *Homo*, *H. habilis*, *rudolfensis*, *gautengensis*, *ergaster*, *erectus* y *georgicus*.
  - A4 · Pleistoceno medio (10): *antecessor*, *cepranensis*, *heidelbergensis*, *rhodesiensis*, *bodoensis*, *helmei*, *naledi*, Nesher Ramla, *longi* y *juluensis*.
  - A5 · Linajes tardíos (5): neandertales, denisovanos, *floresiensis*, *luzonensis* y *Homo sapiens*.
- **P09-B · Procesos (15 páginas, `humanidad/procesos/`).**
  - Sustituyen 9 temas heredados: orígenes de los homininos, australopitecos, *Homo* temprano y primeras dispersiones, diversidad del Pleistoceno, expansión de *H. sapiens*, contacto y mezcla genética, taxonomía (especie, linaje, población), glaciaciones y ambientes humanos, y tecnología lítica (visión general).
  - Nuevas (6): bipedismo, cerebro y desarrollo, fuego y cocina, lenguaje y cognición, dieta y caza, y paleogenómica y ADN antiguo.
- **P09-C · Yacimientos (16 páginas, `humanidad/yacimientos/`).** Atapuerca (Sima del Elefante, Gran Dolina, Sima de los Huesos), Orce y Venta Micena, Olduvai, cuenca del Turkana (Koobi Fora, Nariokotome, Lomekwi), Afar (Hadar y Middle Awash), Laetoli, Cuna de la Humanidad (Sterkfontein, Swartkrans, Rising Star, Malapa), Dmanisi, Zhoukoudian, Sangiran y Trinil, Liang Bua, Denisova, Jebel Irhoud, Omo Kibish, Levante (Skhul, Qafzeh, Misliya, Tabun) y Gibraltar (Gorham y Vanguard) junto con El Sidrón.
- **P09-D · Tecnologías líticas (10 páginas, `humanidad/tecnologias/`).** Lomekwiense, Olduvayense, Achelense, Levallois y Musteriense, Edad de Piedra Media africana, industrias del este de Asia (línea de Movius), industrias de transición (Châtelperroniense, Uluzziense), Auriñaciense, Gravetiense, y Solutrense con Magdaleniense. La sociedad y el arte del Paleolítico superior quedan para P10.
- **Entregas.**
  - 0.70.0: P09-0 ✅ (21/11/2026).
  - 0.71.0: A1–A3 ✅ (22/11/2026).
  - 0.72.0: A4 y A5 ✅ (22/11/2026); las 39 especies completas.
  - 0.73.0: P09-B ✅ (22/11/2026), 15 procesos.
  - 0.74.0: P09-C ✅ (23/11/2026), con enlaces de la enciclopedia a los puntos del mapa.
  - 0.75.0: P09-D ✅ (23/11/2026) y cierre de la fase.

  Se trabaja con dos agentes a la vez y de 5 a 8 páginas por agente, con imágenes libres únicas en `medios/humanidad-…`.

**P10 · Del Paleolítico superior al Neolítico**
Paleolítico superior y arte rupestre, Último Máximo Glacial, poblamiento de América por Beringia, Mesolítico, Holoceno temprano, Neolítico y domesticación por focos (Creciente Fértil, China, Mesoamérica, Andes, Sahel, Nueva Guinea), megalitismo, primeros metales. Páginas para las **culturas del mapa** (las 503 de `Países/CULTURE-*`, agrupadas por familias cuando sean muy afines), p. ej. «Tierras bajas aluviales · comunidades mesolíticas».
*Volumen:* ~60 monografías + fichas B/C de culturas.

### Bloque 4 · Historia: «El mundo en…», entidades, personas y eventos

Cada fase histórica entrega cinco cosas para su intervalo:
1. **Anales año a año** (requisito del propietario, 7/11/2026): una página «El mundo en *año*» para **cada año** desde el 3000 a. C. hasta hoy, con la situación mundial en todos sus aspectos (política, guerras, economía, sociedad, religión, ciencia, cultura, clima y catástrofes) desglosada por regiones. En la Antigüedad remota, donde muchos años no tienen hechos fechados, la página anual se apoya en el panorama de su década o siglo y recoge todo lo fechado que exista, sin inventar sucesos; desde la época clásica, y sobre todo desde la Edad Media, cada año tiene contenido propio.
2. **Contextos** de década, siglo y época con desglose por regiones (Europa, Mediterráneo, Oriente Próximo, África, Asia meridional, Asia oriental, América, Oceanía).
3. **Entidades**: imperios, reinos y estados del mapa en ese intervalo.
4. **Personas**: biografías A/B de los dirigentes y figuras clave (no solo gobernantes: también Aristóteles, Confucio, Colón, Newton… cuando sean imprescindibles para el contexto).
5. **Eventos y obras**: guerras, batallas, revoluciones, pandemias, tratados, monumentos.

| Fase | Intervalo | Ejemplos de contenido | Páginas temáticas (sin contar anales) |
|---|---|---|---|
| **P11** | 3500–1200 a.C. | Sumer, Acad, Egipto (Reinos Antiguo, Medio y Nuevo; Sesostris I, Amenemhat I, Keops, Hatshepsut, Ramsés II), pirámides de Guiza, Harappa, Shang, Hititas, Babilonia y Hammurabi, colapso de la Edad del Bronce | ~140 |
| **P12** | 1200–500 a.C. | Asiria, Neobabilonia, Fenicia, Israel y Judá, Zhou, Olmecas, Grecia arcaica, Persia aqueménida (Ciro, Darío) | ~130 |
| **P13** | 500 a.C.–1 d.C. | Guerras Médicas, Atenas, Alejandro Magno, Diádocos, República romana, Cartago y Guerras Púnicas, Maurya y Ashoka, Qin Shi Huang, Han, Julio César, Augusto | ~180 |
| **P14** | 1–600 | Imperio romano (Tiberio, Trajano, Constantino…), Han y Tres Reinos, Kushán, Sasánidas, Gupta, Teotihuacán, maya clásico, caída de Occidente, Justiniano y **plaga de Justiniano** | ~200 |
| **P15** | 600–1000 | Mahoma y expansión del islam, califatos omeya y abasí, Tang, Carlomagno, vikingos, Bizancio, Ghana, Tiahuanaco | ~180 |
| **P16** | 1000–1450 | Cruzadas, Sacro Imperio, Castilla y Aragón, Song, **Imperio mongol** y Yuan, Mali y Mansa Musa, **Peste Negra**, Guerra de los Cien Años, Tenochtitlan, Inca | ~250 |
| **P17** | 1450–1650 | Caída de Constantinopla, Reyes Católicos, Colón y la era de los descubrimientos, Imperios español y portugués, Otomano (Solimán), Ming, Mogol (Akbar), Reforma, Guerra de los Treinta Años | ~260 |
| **P18** | 1650–1789 | Absolutismo (Luis XIV), Qing, Revolución Gloriosa, Guerra de Sucesión española, Ilustración, Guerra de los Siete Años, independencia de EE. UU. | ~220 |
| **P19** | 1789–1914 | Revolución francesa, Napoleón, independencias americanas, Revolución industrial, unificaciones de Italia y Alemania, Meiji, reparto de África, imperialismo | ~280 |
| **P20** | 1914–1945 | Primera Guerra Mundial, Revolución rusa, gripe de 1918, entreguerras, Guerra Civil española, **Segunda Guerra Mundial** con contexto **año a año** | ~260 |
| **P21** | 1945–2026 | Guerra Fría, descolonización, China maoísta, carrera espacial (**Luna 1969**, Nixon), fin de la URSS, globalización, siglo XXI hasta 2026 | ~300 |

### Bloque 5 · Cobertura total e integración

**P22 · Cobertura completa de dirigentes y entidades**
Fichas B/C para todos los dirigentes y entidades que no tengan monografía: compilación desde Wikidata (fechas, cargos, predecesor/sucesor, dinastía) más resumen redactado, con enlaces. Objetivo: que **ningún nombre de una ficha** quede sin página.

**P23 · Temas transversales**
Pandemias a lo largo de la historia (lista y páginas), religiones, escritura, ciencia y técnica, comercio (Ruta de la Seda…), exploraciones, maravillas del mundo, demografía mundial con gráfico de población, evolución de las formas de gobierno.

**P24 · Revisión integral y cierre**
Auditoría de enlaces, repeticiones, fechas y fuentes; rendimiento; accesibilidad y móvil; actualización completa de `agentes.md`, `tareas.md`, `CHANGELOG.md`; versión mayor.

### Fases opcionales (a decidir)

- **P-X1 · Fichas de país simplificadas**: fichas del mapa escuetas y elegantes (nombre, bandera, dirigentes con enlace a la enciclopedia, capital, dos datos), con lo técnico movido a la enciclopedia. Puede adelantarse si se prefiere.
- **P-X2 · Idiomas**: traducción de la interfaz y, por niveles, de la enciclopedia (ca, es, en, fr, de, pt, it y los idiomas de ampliación).

**Total: 25 fases (P00–P24) + 2 opcionales.** Volumen estimado al final: ~3.000–4.500 páginas temáticas escritas (A/B), **más ~5.000 páginas de anales anuales** (3000 a. C.–2026), más fichas generadas para todos los dirigentes y entidades. Las fases de historia con más volumen (P16–P21) podrán dividirse en subpartes (por ejemplo P20a, P20b) para entregarlas por tandas sin perder profundidad.

---

## 5. Norma editorial (desde la versión 0.60.0)

Exigencia del propietario: la enciclopedia es la parte técnica del proyecto y debe tener nivel universitario o de doctorado. Cada página, sea una unidad geológica, un tema, un año, una persona o un acontecimiento, tiene **al menos 1.500 palabras**; las unidades amplias (eones, eras, periodos) y los panoramas, bastantes más. Cada página explica por qué se llama así, cómo y por qué se definen sus límites, dónde se observa, cómo era el mundo, qué pruebas hay y qué se debate, con tablas, gráficos, mapas, líneas de tiempo e imágenes que no se repiten entre páginas. Objetivo final: varios millones de palabras. El compilador avisa de cualquier página por debajo del mínimo.

## 6. Forma de trabajo en cada fase

1. Investigar primero (Wikipedia y fuentes especializadas), redactar después.
2. Escribir en `enciclopedia/`; tocar `src/` solo cuando la fase lo requiera.
3. Ejecutar compilador, `tsc`, pruebas unitarias y una comprobación visual propia en navegador.
4. Actualizar este plan (estado de la fase), `tareas.md`, `agentes.md` y `CHANGELOG.md`.
5. Entregar los comandos de Git y de ejecución local. El propietario sube; no se esperan ni sondean Actions/Pages.

## 7. Comandos útiles

**Reparar el clon actual (Windows, PowerShell):**

```powershell
cd D:\Proyectos\Historicmap
git config --global core.longpaths true
git reset --hard HEAD
git status
```

**Ver el proyecto en local mientras Actions despliega:**

```powershell
cd D:\Proyectos\Historicmap
npm ci
npm run dev
```

Abrir http://127.0.0.1:5173/ . Para pararlo, `Ctrl+C`. No ejecutar `npm run build` para ver en local: regenera archivos preparados y puede dejar cambios en el árbol de trabajo.

## 8. Estado de las fases

| Fase | Estado |
|---|---|
| P00 | ✅ Completada (7/11/2026) |
| P01 | ✅ Completada (7/11/2026) · versión 0.57.0 |
| P02 | ✅ Completada (7/11/2026) · versión 0.58.0 |
| P03 | ✅ Completada (7/11/2026) · versión 0.59.0 · 29 páginas |
| P01–P03 (revisión) | ✅ Reescritas a nivel universitario (8/11/2026) · versión 0.60.0 · 37 páginas, ≈ 127.500 palabras |
| P04 | ✅ Proterozoico completo (8/11/2026) · versión 0.61.0 · 28 páginas, ≈ 95.600 palabras |
| P05 | ✅ Paleozoico completo (14/11/2026) · versiones 0.62.0–0.64.0 · 100 páginas, ≈ 319.000 palabras |
| P06 | ✅ Mesozoico completo (17/11/2026) · versión 0.67.0 · 57 páginas, ≈ 224.600 palabras |
| P07 | ✅ Cenozoico completo (17/11/2026) · versión 0.68.0 · 47 páginas, ≈ 167.200 palabras |
| P08 | ✅ Procesos y bestiario (18/11/2026) · versión 0.69.0 · 96 páginas, ≈ 259.000 palabras |
| P09 | ✅ Evolución humana completa (23/11/2026) · versiones 0.70.0–0.75.0 · 81 páginas, ≈ 403.000 palabras |
| P10–P24 | Pendientes |
